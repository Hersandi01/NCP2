# NCP (Non-Conformance Product) Management System

## Overview

Sistem manajemen NCP (Non-Conformance Product) adalah aplikasi web modern yang dirancang untuk mengelola laporan ketidaksesuaian produk dalam lingkungan manufaktur. Sistem ini menggunakan workflow approval multi-level dengan role-based access control untuk memastikan proses quality assurance yang terstruktur dan dapat diaudit.

## 🚀 Features

### Core Features
- **Multi-Level Approval Workflow**: 4 tahap approval (QA Leader → Team Leader → Process Lead → QA Manager)
- **Role-Based Access Control**: 6 peran berbeda dengan hak akses yang disesuaikan
- **Real-time Dashboard**: Analytics dan statistik real-time untuk setiap role
- **Audit Trail**: Tracking lengkap semua perubahan dan keputusan
- **File Attachments**: Upload dan manajemen file pendukung
- **Auto-numbering**: Penomoran otomatis untuk laporan NCP

### Advanced Features
- **Analytics Dashboard**: Charts dan metrics untuk analisis trend
- **Export CSV**: Export data laporan dalam format CSV
- **User Management**: Manajemen pengguna untuk Superadmin
- **Notification System**: Notifikasi real-time untuk approval workflow
- **Advanced Search**: Pencarian dan filtering yang powerful
- **Settings Management**: Konfigurasi department dan sistem

## 🏗️ Architecture

### Tech Stack
- **Frontend**: Next.js 15 (App Router), React 18, TypeScript
- **Backend**: Next.js API Routes, Server Actions
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth
- **UI Framework**: Tailwind CSS v4, shadcn/ui
- **Charts**: Recharts
- **State Management**: React Server Components + SWR

### Project Structure
\`\`\`
├── app/                    # Next.js App Router pages
│   ├── auth/              # Authentication pages
│   ├── dashboard/         # Main dashboard
│   ├── reports/           # NCP reports management
│   ├── approvals/         # Approval workflow
│   ├── analytics/         # Analytics dashboard
│   ├── users/             # User management
│   ├── settings/          # System settings
│   └── notifications/     # Notifications
├── components/            # Reusable React components
│   ├── dashboard/         # Dashboard components
│   ├── reports/           # Report-related components
│   ├── approvals/         # Approval components
│   ├── analytics/         # Analytics components
│   ├── users/             # User management components
│   └── settings/          # Settings components
├── lib/                   # Utility libraries
│   ├── supabase/          # Supabase client configuration
│   └── types/             # TypeScript type definitions
└── scripts/               # Database migration scripts
\`\`\`

## 🔧 Setup & Installation

### Prerequisites
- Node.js 18+ 
- npm atau yarn
- Supabase account

### Environment Variables
\`\`\`env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
\`\`\`

### Installation Steps

1. **Clone repository**
\`\`\`bash
git clone <repository-url>
cd ncp-management-system
\`\`\`

2. **Install dependencies**
\`\`\`bash
npm install
\`\`\`

3. **Setup Supabase**
   - Create new Supabase project
   - Run database migration scripts in order:
     - `scripts/001_create_database_schema.sql`
     - `scripts/002_create_functions_and_triggers.sql`
     - `scripts/003_seed_initial_data.sql`
     - `scripts/004_create_workflow_functions.sql`

4. **Configure environment variables**
\`\`\`bash
cp .env.example .env.local
# Edit .env.local with your Supabase credentials
\`\`\`

5. **Run development server**
\`\`\`bash
npm run dev
\`\`\`

## 👥 User Roles & Permissions

### 1. Superadmin
- **Full system access**
- User management (create, edit, delete users)
- System settings configuration
- View all reports and analytics
- Override any approval decisions

### 2. QA Inspector
- **Report Creation & Management**
- Create new NCP reports
- Edit draft reports
- View own reports
- Upload attachments

### 3. QA Leader
- **First Level Approval**
- Review and approve/reject reports from QA Inspector
- View reports assigned for review
- Add comments and recommendations
- Assign next approver (Team Leader)

### 4. Team Leader
- **Second Level Approval**
- Review reports approved by QA Leader
- Approve/reject with detailed comments
- Assign next approver (Process Lead)
- View team performance metrics

### 5. Process Lead
- **Third Level Approval**
- Review reports from Team Leader
- Technical evaluation and approval
- Assign final approver (QA Manager)
- Process improvement recommendations

### 6. QA Manager
- **Final Approval Authority**
- Final review and approval/rejection
- System-wide analytics access
- Quality metrics oversight
- Strategic decision making

## 🔄 Workflow Process

### 1. Report Creation
\`\`\`
QA Inspector → Create Report → Save as Draft/Submit
\`\`\`

### 2. Approval Workflow
\`\`\`
Submit → QA Leader Review → Team Leader Review → Process Lead Review → QA Manager Final Approval
\`\`\`

### 3. Status Flow
\`\`\`
Draft → Submitted → QA Leader Review → Team Leader Review → Process Lead Review → QA Manager Review → Approved/Rejected
\`\`\`

## 📊 Database Schema

### Core Tables

#### `profiles`
- User profile information
- Role assignments
- Department associations

#### `ncp_reports`
- Main NCP report data
- Status tracking
- Metadata and timestamps

#### `ncp_approvals`
- Approval workflow tracking
- Approver assignments
- Decision history

#### `audit_logs`
- Complete audit trail
- Change tracking
- User activity logs

#### `departments`
- Organizational structure
- Department hierarchy

#### `notifications`
- System notifications
- Approval alerts
- Status updates

## 🔐 Security Features

### Row Level Security (RLS)
- Database-level access control
- Role-based data filtering
- Secure data isolation

### Authentication
- Supabase Auth integration
- Email/password authentication
- Session management
- Middleware protection

### Authorization
- Role-based permissions
- Route protection
- API endpoint security
- Data access controls

## 📈 Analytics & Reporting

### Dashboard Metrics
- Total reports by status
- Approval rates and trends
- Department performance
- User activity statistics

### Export Capabilities
- CSV export for reports
- Filtered data export
- Custom date ranges
- Bulk data operations

## 🚀 Deployment

### Vercel Deployment
1. Connect repository to Vercel
2. Configure environment variables
3. Deploy automatically on push

### Database Setup
1. Create Supabase project
2. Run migration scripts
3. Configure RLS policies
4. Set up authentication

## 🛠️ Development

### Code Standards
- TypeScript strict mode
- ESLint configuration
- Prettier formatting
- Component-based architecture

### Testing Strategy
- Unit tests for utilities
- Integration tests for API routes
- E2E tests for critical workflows
- Database migration testing

## 📚 API Documentation

### Authentication Endpoints
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/user` - Get current user

### Reports API
- `GET /api/reports` - List reports with filtering
- `POST /api/reports` - Create new report
- `GET /api/reports/[id]` - Get report details
- `PUT /api/reports/[id]` - Update report
- `DELETE /api/reports/[id]` - Delete report

### Approvals API
- `GET /api/approvals` - List pending approvals
- `POST /api/approvals/[id]/approve` - Approve report
- `POST /api/approvals/[id]/reject` - Reject report
- `GET /api/approvals/history` - Approval history

### Analytics API
- `GET /api/analytics/dashboard` - Dashboard metrics
- `GET /api/analytics/reports` - Report analytics
- `GET /api/analytics/users` - User analytics

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the documentation wiki

---

**Version**: 1.0.0  
**Last Updated**: December 2024  
**Maintained by**: Development Team
