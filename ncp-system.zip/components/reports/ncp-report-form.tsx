"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, Upload, X, Save, Send } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import type { Department, NCPReport } from "@/lib/types/database"

interface NCPReportFormProps {
  departments: Department[]
  userId: string
  mode: "create" | "edit"
  initialData?: Partial<NCPReport>
}

const CATEGORIES = [
  { value: "product_defect", label: "Product Defect" },
  { value: "process_deviation", label: "Process Deviation" },
  { value: "documentation_error", label: "Documentation Error" },
  { value: "equipment_failure", label: "Equipment Failure" },
  { value: "material_issue", label: "Material Issue" },
  { value: "other", label: "Other" },
]

const PRIORITIES = [
  { value: "low", label: "Low" },
  { value: "medium", label: "Medium" },
  { value: "high", label: "High" },
  { value: "critical", label: "Critical" },
]

export function NCPReportForm({ departments, userId, mode, initialData }: NCPReportFormProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Form state
  const [formData, setFormData] = useState({
    title: initialData?.title || "",
    description: initialData?.description || "",
    category: initialData?.category || "",
    priority: initialData?.priority || "medium",
    department_id: initialData?.department_id || "",
    product_name: initialData?.product_name || "",
    batch_number: initialData?.batch_number || "",
    quantity_affected: initialData?.quantity_affected || "",
    date_discovered: initialData?.date_discovered ? new Date(initialData.date_discovered) : undefined,
    location: initialData?.location || "",
    root_cause: initialData?.root_cause || "",
    immediate_action: initialData?.immediate_action || "",
    corrective_action: initialData?.corrective_action || "",
    preventive_action: initialData?.preventive_action || "",
  })

  const [attachments, setAttachments] = useState<File[]>([])

  const handleInputChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])
    setAttachments((prev) => [...prev, ...files])
  }

  const removeAttachment = (index: number) => {
    setAttachments((prev) => prev.filter((_, i) => i !== index))
  }

  const validateForm = () => {
    if (!formData.title.trim()) return "Title is required"
    if (!formData.description.trim()) return "Description is required"
    if (!formData.category) return "Category is required"
    if (!formData.priority) return "Priority is required"
    return null
  }

  const handleSubmit = async (action: "save" | "submit") => {
    const validationError = validateForm()
    if (validationError) {
      setError(validationError)
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()

      const reportData = {
        ...formData,
        reporter_id: userId,
        status: action === "submit" ? "submitted" : "draft",
        quantity_affected: formData.quantity_affected ? Number.parseInt(formData.quantity_affected) : null,
        date_discovered: formData.date_discovered?.toISOString(),
        submitted_at: action === "submit" ? new Date().toISOString() : null,
      }

      let result
      if (mode === "create") {
        // Generate NCP number
        const { data: ncpNumber } = await supabase.rpc("generate_ncp_number")

        result = await supabase
          .from("ncp_reports")
          .insert({
            ...reportData,
            ncp_number: ncpNumber,
          })
          .select()
          .single()
      } else {
        result = await supabase.from("ncp_reports").update(reportData).eq("id", initialData?.id).select().single()
      }

      if (result.error) throw result.error

      // Handle file uploads if any
      if (attachments.length > 0 && result.data) {
        for (const file of attachments) {
          const fileName = `${result.data.id}/${Date.now()}-${file.name}`

          // Upload to Supabase storage (you'll need to set up storage bucket)
          // For now, we'll just store the file info in the attachments table
          await supabase.from("ncp_attachments").insert({
            ncp_report_id: result.data.id,
            file_name: file.name,
            file_path: fileName,
            file_size: file.size,
            mime_type: file.type,
            uploaded_by: userId,
          })
        }
      }

      router.push(`/reports/${result.data.id}`)
    } catch (error: any) {
      setError(error.message || "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
      {/* Basic Information */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground">Basic Information</CardTitle>
          <CardDescription className="text-muted-foreground">
            Provide basic details about the non-conformance
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="title" className="text-card-foreground">
                Title *
              </Label>
              <Input
                id="title"
                placeholder="Brief description of the issue"
                value={formData.title}
                onChange={(e) => handleInputChange("title", e.target.value)}
                className="bg-input border-border text-foreground"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="category" className="text-card-foreground">
                Category *
              </Label>
              <Select value={formData.category} onValueChange={(value) => handleInputChange("category", value)}>
                <SelectTrigger className="bg-input border-border text-foreground">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  {CATEGORIES.map((category) => (
                    <SelectItem key={category.value} value={category.value} className="text-popover-foreground">
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-card-foreground">
              Description *
            </Label>
            <Textarea
              id="description"
              placeholder="Detailed description of the non-conformance"
              value={formData.description}
              onChange={(e) => handleInputChange("description", e.target.value)}
              className="bg-input border-border text-foreground min-h-[100px]"
              required
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="priority" className="text-card-foreground">
                Priority *
              </Label>
              <Select value={formData.priority} onValueChange={(value) => handleInputChange("priority", value)}>
                <SelectTrigger className="bg-input border-border text-foreground">
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  {PRIORITIES.map((priority) => (
                    <SelectItem key={priority.value} value={priority.value} className="text-popover-foreground">
                      {priority.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="department" className="text-card-foreground">
                Department
              </Label>
              <Select
                value={formData.department_id}
                onValueChange={(value) => handleInputChange("department_id", value)}
              >
                <SelectTrigger className="bg-input border-border text-foreground">
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  {departments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id} className="text-popover-foreground">
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Product/Process Details */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground">Product/Process Details</CardTitle>
          <CardDescription className="text-muted-foreground">
            Specific information about the affected product or process
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="product_name" className="text-card-foreground">
                Product Name
              </Label>
              <Input
                id="product_name"
                placeholder="Name of affected product"
                value={formData.product_name}
                onChange={(e) => handleInputChange("product_name", e.target.value)}
                className="bg-input border-border text-foreground"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="batch_number" className="text-card-foreground">
                Batch/Lot Number
              </Label>
              <Input
                id="batch_number"
                placeholder="Batch or lot number"
                value={formData.batch_number}
                onChange={(e) => handleInputChange("batch_number", e.target.value)}
                className="bg-input border-border text-foreground"
              />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="quantity_affected" className="text-card-foreground">
                Quantity Affected
              </Label>
              <Input
                id="quantity_affected"
                type="number"
                placeholder="Number of units"
                value={formData.quantity_affected}
                onChange={(e) => handleInputChange("quantity_affected", e.target.value)}
                className="bg-input border-border text-foreground"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-card-foreground">Date Discovered</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal bg-input border-border text-foreground",
                      !formData.date_discovered && "text-muted-foreground",
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.date_discovered ? format(formData.date_discovered, "PPP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 bg-popover border-border">
                  <Calendar
                    mode="single"
                    selected={formData.date_discovered}
                    onSelect={(date) => handleInputChange("date_discovered", date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="space-y-2">
              <Label htmlFor="location" className="text-card-foreground">
                Location
              </Label>
              <Input
                id="location"
                placeholder="Where was it discovered"
                value={formData.location}
                onChange={(e) => handleInputChange("location", e.target.value)}
                className="bg-input border-border text-foreground"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Root Cause Analysis */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground">Root Cause Analysis & Actions</CardTitle>
          <CardDescription className="text-muted-foreground">
            Analysis and corrective actions (can be filled later)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="root_cause" className="text-card-foreground">
              Root Cause
            </Label>
            <Textarea
              id="root_cause"
              placeholder="What caused this non-conformance?"
              value={formData.root_cause}
              onChange={(e) => handleInputChange("root_cause", e.target.value)}
              className="bg-input border-border text-foreground"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="immediate_action" className="text-card-foreground">
              Immediate Action
            </Label>
            <Textarea
              id="immediate_action"
              placeholder="What immediate action was taken?"
              value={formData.immediate_action}
              onChange={(e) => handleInputChange("immediate_action", e.target.value)}
              className="bg-input border-border text-foreground"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="corrective_action" className="text-card-foreground">
              Corrective Action
            </Label>
            <Textarea
              id="corrective_action"
              placeholder="What corrective action will be taken?"
              value={formData.corrective_action}
              onChange={(e) => handleInputChange("corrective_action", e.target.value)}
              className="bg-input border-border text-foreground"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="preventive_action" className="text-card-foreground">
              Preventive Action
            </Label>
            <Textarea
              id="preventive_action"
              placeholder="What preventive action will prevent recurrence?"
              value={formData.preventive_action}
              onChange={(e) => handleInputChange("preventive_action", e.target.value)}
              className="bg-input border-border text-foreground"
            />
          </div>
        </CardContent>
      </Card>

      {/* Attachments */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground">Attachments</CardTitle>
          <CardDescription className="text-muted-foreground">
            Upload supporting documents, images, or files
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
            <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-muted-foreground mb-2">Drag and drop files here, or click to browse</p>
            <input
              type="file"
              multiple
              onChange={handleFileUpload}
              className="hidden"
              id="file-upload"
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif"
            />
            <Button
              type="button"
              variant="outline"
              onClick={() => document.getElementById("file-upload")?.click()}
              className="border-border text-foreground hover:bg-accent"
            >
              Choose Files
            </Button>
          </div>

          {attachments.length > 0 && (
            <div className="space-y-2">
              <Label className="text-card-foreground">Selected Files:</Label>
              {attachments.map((file, index) => (
                <div key={index} className="flex items-center justify-between p-2 bg-muted rounded-md">
                  <span className="text-sm text-muted-foreground">{file.name}</span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeAttachment(index)}
                    className="text-destructive hover:text-destructive"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Error Display */}
      {error && (
        <div className="text-destructive text-sm bg-destructive/10 p-3 rounded-md border border-destructive/20">
          {error}
        </div>
      )}

      {/* Actions */}
      <div className="flex justify-end space-x-4">
        <Button
          type="button"
          variant="outline"
          onClick={() => router.back()}
          className="border-border text-foreground hover:bg-accent"
        >
          Cancel
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={() => handleSubmit("save")}
          disabled={isLoading}
          className="border-border text-foreground hover:bg-accent"
        >
          <Save className="h-4 w-4 mr-2" />
          {isLoading ? "Saving..." : "Save Draft"}
        </Button>
        <Button
          type="button"
          onClick={() => handleSubmit("submit")}
          disabled={isLoading}
          className="bg-primary hover:bg-primary/90 text-primary-foreground"
        >
          <Send className="h-4 w-4 mr-2" />
          {isLoading ? "Submitting..." : "Submit Report"}
        </Button>
      </div>
    </form>
  )
}
