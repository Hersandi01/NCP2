"use client"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"

interface ExportButtonProps {
  filters?: {
    status?: string
    priority?: string
    category?: string
    dateFrom?: string
    dateTo?: string
  }
}

export function ExportButton({ filters = {} }: ExportButtonProps) {
  const [isExporting, setIsExporting] = useState(false)

  const handleExport = async () => {
    setIsExporting(true)
    try {
      const supabase = createClient()

      let query = supabase.from("ncp_reports").select(`
          *,
          reporter:profiles!ncp_reports_reporter_id_fkey(full_name, email),
          department:departments(name),
          qa_leader:profiles!ncp_reports_qa_leader_id_fkey(full_name),
          team_leader:profiles!ncp_reports_team_leader_id_fkey(full_name),
          process_lead:profiles!ncp_reports_process_lead_id_fkey(full_name),
          qa_manager:profiles!ncp_reports_qa_manager_id_fkey(full_name)
        `)

      // Apply filters
      if (filters.status && filters.status !== "all") {
        query = query.eq("status", filters.status)
      }
      if (filters.priority && filters.priority !== "all") {
        query = query.eq("priority", filters.priority)
      }
      if (filters.category && filters.category !== "all") {
        query = query.eq("category", filters.category)
      }
      if (filters.dateFrom) {
        query = query.gte("created_at", filters.dateFrom)
      }
      if (filters.dateTo) {
        query = query.lte("created_at", filters.dateTo)
      }

      const { data: reports } = await query

      if (reports) {
        // Convert to CSV
        const csvContent = convertToCSV(reports)

        // Download file
        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
        const link = document.createElement("a")
        const url = URL.createObjectURL(blob)
        link.setAttribute("href", url)
        link.setAttribute("download", `ncp_reports_${new Date().toISOString().split("T")[0]}.csv`)
        link.style.visibility = "hidden"
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
      }
    } catch (error) {
      console.error("Error exporting data:", error)
    } finally {
      setIsExporting(false)
    }
  }

  const convertToCSV = (data: any[]) => {
    const headers = [
      "NCP Number",
      "Title",
      "Description",
      "Category",
      "Priority",
      "Status",
      "Reporter",
      "Department",
      "Product Name",
      "Batch Number",
      "Quantity Affected",
      "Date Discovered",
      "Location",
      "Root Cause",
      "Immediate Action",
      "Corrective Action",
      "Preventive Action",
      "QA Leader",
      "Team Leader",
      "Process Lead",
      "QA Manager",
      "Created At",
      "Updated At",
    ]

    const csvRows = [
      headers.join(","),
      ...data.map((report) =>
        [
          `"${report.ncp_number}"`,
          `"${report.title}"`,
          `"${report.description.replace(/"/g, '""')}"`,
          `"${report.category}"`,
          `"${report.priority}"`,
          `"${report.status}"`,
          `"${report.reporter?.full_name || ""}"`,
          `"${report.department?.name || ""}"`,
          `"${report.product_name || ""}"`,
          `"${report.batch_number || ""}"`,
          `"${report.quantity_affected || ""}"`,
          `"${report.date_discovered || ""}"`,
          `"${report.location || ""}"`,
          `"${(report.root_cause || "").replace(/"/g, '""')}"`,
          `"${(report.immediate_action || "").replace(/"/g, '""')}"`,
          `"${(report.corrective_action || "").replace(/"/g, '""')}"`,
          `"${(report.preventive_action || "").replace(/"/g, '""')}"`,
          `"${report.qa_leader?.full_name || ""}"`,
          `"${report.team_leader?.full_name || ""}"`,
          `"${report.process_lead?.full_name || ""}"`,
          `"${report.qa_manager?.full_name || ""}"`,
          `"${report.created_at}"`,
          `"${report.updated_at}"`,
        ].join(","),
      ),
    ]

    return csvRows.join("\n")
  }

  return (
    <Button
      onClick={handleExport}
      disabled={isExporting}
      variant="outline"
      className="border-border text-foreground hover:bg-accent bg-transparent"
    >
      <Download className="h-4 w-4 mr-2" />
      {isExporting ? "Exporting..." : "Export CSV"}
    </Button>
  )
}
