"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CheckCircle, XCircle, User } from "lucide-react"
import type { UserRole, NCPReport } from "@/lib/types/database"

interface ApprovalFormProps {
  report: NCPReport & {
    reporter?: { full_name: string }
    department?: { name: string }
  }
  userRole: UserRole
  userId: string
}

const NEXT_APPROVERS = {
  qa_leader: "team_leader",
  team_leader: "process_lead",
  process_lead: "qa_manager",
  qa_manager: null, // Final approval
}

const NEXT_STATUS = {
  qa_leader: "team_leader_review",
  team_leader: "process_lead_review",
  process_lead: "qa_manager_review",
  qa_manager: "approved",
}

export function ApprovalForm({ report, userRole, userId }: ApprovalFormProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [comments, setComments] = useState("")
  const [nextApprover, setNextApprover] = useState("")
  const [availableApprovers, setAvailableApprovers] = useState<any[]>([])

  // Load available approvers when component mounts
  useState(() => {
    const loadApprovers = async () => {
      const nextRole = NEXT_APPROVERS[userRole as keyof typeof NEXT_APPROVERS]
      if (nextRole) {
        const supabase = createClient()
        const { data } = await supabase
          .from("profiles")
          .select("id, full_name")
          .eq("role", nextRole)
          .eq("is_active", true)

        setAvailableApprovers(data || [])
      }
    }
    loadApprovers()
  })

  const handleApproval = async (action: "approve" | "reject") => {
    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()

      const updateData: any = {
        [`${userRole}_id`]: userId,
        [`${userRole}_approved_at`]: new Date().toISOString(),
        [`${userRole}_comments`]: comments || null,
      }

      if (action === "approve") {
        const nextRole = NEXT_APPROVERS[userRole as keyof typeof NEXT_APPROVERS]
        if (nextRole) {
          // Move to next approval stage
          updateData.status = NEXT_STATUS[userRole as keyof typeof NEXT_STATUS]
          if (nextApprover) {
            updateData[`${nextRole}_id`] = nextApprover
          }
        } else {
          // Final approval
          updateData.status = "approved"
          updateData.closed_at = new Date().toISOString()
        }
      } else {
        // Rejected
        updateData.status = "rejected"
        updateData.closed_at = new Date().toISOString()
      }

      const { error: updateError } = await supabase.from("ncp_reports").update(updateData).eq("id", report.id)

      if (updateError) throw updateError

      // Create notification for next approver or reporter
      if (action === "approve" && nextApprover) {
        await supabase.from("notifications").insert({
          user_id: nextApprover,
          ncp_report_id: report.id,
          title: "New NCP Report for Review",
          message: `NCP ${report.ncp_number} has been assigned to you for review.`,
          type: "approval_request",
        })
      } else {
        // Notify reporter of final decision
        await supabase.from("notifications").insert({
          user_id: report.reporter_id,
          ncp_report_id: report.id,
          title: `NCP Report ${action === "approve" ? "Approved" : "Rejected"}`,
          message: `Your NCP report ${report.ncp_number} has been ${action}d.`,
          type: action === "approve" ? "approval_success" : "approval_rejected",
        })
      }

      router.push("/approvals")
      router.refresh()
    } catch (error: any) {
      setError(error.message || "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const nextRole = NEXT_APPROVERS[userRole as keyof typeof NEXT_APPROVERS]
  const isCurrentApprover = report.status === `${userRole}_review`

  if (!isCurrentApprover) {
    return (
      <Card className="bg-card border-border">
        <CardContent className="p-6 text-center">
          <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
          <p className="text-card-foreground">This report has already been processed.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-card-foreground">Approval Decision</CardTitle>
        <CardDescription className="text-muted-foreground">
          Review the report and make your approval decision
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="comments" className="text-card-foreground">
            Comments
          </Label>
          <Textarea
            id="comments"
            placeholder="Add your comments about this report..."
            value={comments}
            onChange={(e) => setComments(e.target.value)}
            className="bg-input border-border text-foreground min-h-[100px]"
          />
        </div>

        {nextRole && availableApprovers.length > 0 && (
          <div className="space-y-2">
            <Label htmlFor="nextApprover" className="text-card-foreground">
              Assign Next Approver ({nextRole.replace("_", " ").toUpperCase()})
            </Label>
            <Select value={nextApprover} onValueChange={setNextApprover}>
              <SelectTrigger className="bg-input border-border text-foreground">
                <SelectValue placeholder="Select next approver" />
              </SelectTrigger>
              <SelectContent className="bg-popover border-border">
                {availableApprovers.map((approver) => (
                  <SelectItem key={approver.id} value={approver.id} className="text-popover-foreground">
                    <div className="flex items-center space-x-2">
                      <User className="h-4 w-4" />
                      <span>{approver.full_name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {error && (
          <div className="text-destructive text-sm bg-destructive/10 p-3 rounded-md border border-destructive/20">
            {error}
          </div>
        )}

        <div className="flex space-x-4 pt-4">
          <Button
            onClick={() => handleApproval("reject")}
            variant="destructive"
            disabled={isLoading}
            className="flex-1"
          >
            <XCircle className="h-4 w-4 mr-2" />
            {isLoading ? "Processing..." : "Reject"}
          </Button>
          <Button
            onClick={() => handleApproval("approve")}
            disabled={isLoading || (nextRole && !nextApprover)}
            className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            {isLoading ? "Processing..." : "Approve"}
          </Button>
        </div>

        {nextRole && !nextApprover && (
          <p className="text-sm text-muted-foreground text-center">
            Please select the next approver before approving this report.
          </p>
        )}
      </CardContent>
    </Card>
  )
}
