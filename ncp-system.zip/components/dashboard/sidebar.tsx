"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  FileText,
  Users,
  Settings,
  Bell,
  BarChart3,
  CheckCircle,
  AlertTriangle,
  Menu,
  X,
  LogOut,
} from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import type { UserRole } from "@/lib/types/database"

interface SidebarProps {
  userRole: UserRole
  userName: string
}

const navigationItems = {
  superadmin: [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "NCP Reports", href: "/reports", icon: FileText },
    { name: "Users", href: "/users", icon: Users },
    { name: "Analytics", href: "/analytics", icon: BarChart3 },
    { name: "Settings", href: "/settings", icon: Settings },
  ],
  qa_inspector: [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "My Reports", href: "/reports", icon: FileText },
    { name: "Create Report", href: "/reports/create", icon: AlertTriangle },
    { name: "Notifications", href: "/notifications", icon: Bell },
  ],
  qa_leader: [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "Reports", href: "/reports", icon: FileText },
    { name: "Pending Approval", href: "/approvals", icon: CheckCircle },
    { name: "Analytics", href: "/analytics", icon: BarChart3 },
  ],
  team_leader: [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "Reports", href: "/reports", icon: FileText },
    { name: "Team Approvals", href: "/approvals", icon: CheckCircle },
    { name: "Analytics", href: "/analytics", icon: BarChart3 },
  ],
  process_lead: [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "Reports", href: "/reports", icon: FileText },
    { name: "Process Approvals", href: "/approvals", icon: CheckCircle },
    { name: "Analytics", href: "/analytics", icon: BarChart3 },
  ],
  qa_manager: [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "All Reports", href: "/reports", icon: FileText },
    { name: "Final Approvals", href: "/approvals", icon: CheckCircle },
    { name: "Analytics", href: "/analytics", icon: BarChart3 },
    { name: "Settings", href: "/settings", icon: Settings },
  ],
}

export function Sidebar({ userRole, userName }: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false)
  const pathname = usePathname()
  const router = useRouter()

  const handleSignOut = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push("/auth/login")
  }

  const items = navigationItems[userRole] || navigationItems.qa_inspector

  return (
    <div
      className={cn(
        "flex flex-col h-screen bg-sidebar border-r border-sidebar-border transition-all duration-300",
        isCollapsed ? "w-16" : "w-64",
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-sidebar-border">
        {!isCollapsed && (
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-sidebar-primary rounded-lg flex items-center justify-center">
              <div className="w-4 h-4 bg-sidebar-primary-foreground rounded-sm"></div>
            </div>
            <span className="font-bold text-sidebar-foreground">NCP System</span>
          </div>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="text-sidebar-foreground hover:bg-sidebar-accent"
        >
          {isCollapsed ? <Menu className="h-4 w-4" /> : <X className="h-4 w-4" />}
        </Button>
      </div>

      {/* User Info */}
      {!isCollapsed && (
        <div className="p-4 border-b border-sidebar-border">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-sidebar-primary rounded-full flex items-center justify-center">
              <span className="text-sidebar-primary-foreground font-medium">{userName.charAt(0).toUpperCase()}</span>
            </div>
            <div>
              <p className="text-sidebar-foreground font-medium text-sm">{userName}</p>
              <p className="text-muted-foreground text-xs capitalize">{userRole.replace("_", " ")}</p>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {items.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href

          return (
            <Link key={item.href} href={item.href}>
              <Button
                variant={isActive ? "default" : "ghost"}
                className={cn(
                  "w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent",
                  isActive && "bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary/90",
                  isCollapsed && "px-2",
                )}
              >
                <Icon className={cn("h-4 w-4", !isCollapsed && "mr-3")} />
                {!isCollapsed && item.name}
              </Button>
            </Link>
          )
        })}
      </nav>

      {/* Sign Out */}
      <div className="p-4 border-t border-sidebar-border">
        <Button
          variant="ghost"
          onClick={handleSignOut}
          className={cn(
            "w-full justify-start text-sidebar-foreground hover:bg-destructive hover:text-destructive-foreground",
            isCollapsed && "px-2",
          )}
        >
          <LogOut className={cn("h-4 w-4", !isCollapsed && "mr-3")} />
          {!isCollapsed && "Sign Out"}
        </Button>
      </div>
    </div>
  )
}
