"use client"

import type React from "react"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Switch } from "@/components/ui/switch"
import { Edit, Search } from "lucide-react"
import type { Profile, Department } from "@/lib/types/database"

interface UserManagementProps {
  users: Profile[]
  departments: Department[]
}

const USER_ROLES = [
  { value: "qa_inspector", label: "QA Inspector" },
  { value: "qa_leader", label: "QA Leader" },
  { value: "team_leader", label: "Team Leader" },
  { value: "process_lead", label: "Process Lead" },
  { value: "qa_manager", label: "QA Manager" },
  { value: "superadmin", label: "Super Admin" },
]

const ROLE_COLORS = {
  qa_inspector: "bg-blue-500",
  qa_leader: "bg-green-500",
  team_leader: "bg-orange-500",
  process_lead: "bg-purple-500",
  qa_manager: "bg-indigo-500",
  superadmin: "bg-red-500",
}

export function UserManagement({ users: initialUsers, departments }: UserManagementProps) {
  const [users, setUsers] = useState(initialUsers)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedRole, setSelectedRole] = useState("all")
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<Profile | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  // Filter users
  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesRole = selectedRole === "all" || user.role === selectedRole
    return matchesSearch && matchesRole
  })

  const handleEditUser = (user: Profile) => {
    setEditingUser(user)
    setIsEditDialogOpen(true)
  }

  const handleUpdateUser = async (updatedData: Partial<Profile>) => {
    if (!editingUser) return

    setIsLoading(true)
    try {
      const supabase = createClient()
      const { error } = await supabase.from("profiles").update(updatedData).eq("id", editingUser.id)

      if (error) throw error

      // Update local state
      setUsers((prev) => prev.map((user) => (user.id === editingUser.id ? { ...user, ...updatedData } : user)))

      setIsEditDialogOpen(false)
      setEditingUser(null)
    } catch (error) {
      console.error("Error updating user:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleToggleUserStatus = async (userId: string, isActive: boolean) => {
    setIsLoading(true)
    try {
      const supabase = createClient()
      const { error } = await supabase.from("profiles").update({ is_active: isActive }).eq("id", userId)

      if (error) throw error

      // Update local state
      setUsers((prev) => prev.map((user) => (user.id === userId ? { ...user, is_active: isActive } : user)))
    } catch (error) {
      console.error("Error updating user status:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground">Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search users..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-input border-border text-foreground"
                />
              </div>
            </div>
            <Select value={selectedRole} onValueChange={setSelectedRole}>
              <SelectTrigger className="w-[180px] bg-input border-border text-foreground">
                <SelectValue placeholder="Filter by role" />
              </SelectTrigger>
              <SelectContent className="bg-popover border-border">
                <SelectItem value="all" className="text-popover-foreground">
                  All Roles
                </SelectItem>
                {USER_ROLES.map((role) => (
                  <SelectItem key={role.value} value={role.value} className="text-popover-foreground">
                    {role.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground">Users ({filteredUsers.length})</CardTitle>
          <CardDescription className="text-muted-foreground">Manage system users and their permissions</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-border">
                <TableHead className="text-card-foreground">User</TableHead>
                <TableHead className="text-card-foreground">Role</TableHead>
                <TableHead className="text-card-foreground">Department</TableHead>
                <TableHead className="text-card-foreground">Status</TableHead>
                <TableHead className="text-card-foreground">Joined</TableHead>
                <TableHead className="text-card-foreground">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id} className="border-border">
                  <TableCell>
                    <div>
                      <div className="font-medium text-card-foreground">{user.full_name}</div>
                      <div className="text-sm text-muted-foreground">{user.email}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={`${ROLE_COLORS[user.role]} text-white`}>
                      {USER_ROLES.find((r) => r.value === user.role)?.label}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-card-foreground">{user.department || "—"}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={user.is_active}
                        onCheckedChange={(checked) => handleToggleUserStatus(user.id, checked)}
                        disabled={isLoading}
                      />
                      <span className="text-sm text-muted-foreground">{user.is_active ? "Active" : "Inactive"}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-card-foreground">
                    {new Date(user.created_at).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditUser(user)}
                      className="border-border text-foreground hover:bg-accent bg-transparent"
                    >
                      <Edit className="h-3 w-3 mr-1" />
                      Edit
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit User Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-card-foreground">Edit User</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Update user information and permissions
            </DialogDescription>
          </DialogHeader>
          {editingUser && (
            <EditUserForm
              user={editingUser}
              departments={departments}
              onSave={handleUpdateUser}
              onCancel={() => setIsEditDialogOpen(false)}
              isLoading={isLoading}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

interface EditUserFormProps {
  user: Profile
  departments: Department[]
  onSave: (data: Partial<Profile>) => void
  onCancel: () => void
  isLoading: boolean
}

function EditUserForm({ user, departments, onSave, onCancel, isLoading }: EditUserFormProps) {
  const [formData, setFormData] = useState({
    full_name: user.full_name,
    role: user.role,
    department: user.department || "",
    phone: user.phone || "",
    is_active: user.is_active,
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSave(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="full_name" className="text-card-foreground">
          Full Name
        </Label>
        <Input
          id="full_name"
          value={formData.full_name}
          onChange={(e) => setFormData((prev) => ({ ...prev, full_name: e.target.value }))}
          className="bg-input border-border text-foreground"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="role" className="text-card-foreground">
          Role
        </Label>
        <Select
          value={formData.role}
          onValueChange={(value) => setFormData((prev) => ({ ...prev, role: value as any }))}
        >
          <SelectTrigger className="bg-input border-border text-foreground">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-popover border-border">
            {USER_ROLES.map((role) => (
              <SelectItem key={role.value} value={role.value} className="text-popover-foreground">
                {role.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="department" className="text-card-foreground">
          Department
        </Label>
        <Select
          value={formData.department}
          onValueChange={(value) => setFormData((prev) => ({ ...prev, department: value }))}
        >
          <SelectTrigger className="bg-input border-border text-foreground">
            <SelectValue placeholder="Select department" />
          </SelectTrigger>
          <SelectContent className="bg-popover border-border">
            <SelectItem value="" className="text-popover-foreground">
              No Department
            </SelectItem>
            {departments.map((dept) => (
              <SelectItem key={dept.id} value={dept.name} className="text-popover-foreground">
                {dept.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="phone" className="text-card-foreground">
          Phone
        </Label>
        <Input
          id="phone"
          value={formData.phone}
          onChange={(e) => setFormData((prev) => ({ ...prev, phone: e.target.value }))}
          className="bg-input border-border text-foreground"
        />
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          checked={formData.is_active}
          onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, is_active: checked }))}
        />
        <Label className="text-card-foreground">Active User</Label>
      </div>

      <div className="flex justify-end space-x-2 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          className="border-border text-foreground hover:bg-accent bg-transparent"
        >
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading} className="bg-primary hover:bg-primary/90 text-primary-foreground">
          {isLoading ? "Saving..." : "Save Changes"}
        </Button>
      </div>
    </form>
  )
}
