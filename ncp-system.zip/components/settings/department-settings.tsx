"use client"

import type React from "react"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Switch } from "@/components/ui/switch"
import { Plus, Edit } from "lucide-react"
import type { Department } from "@/lib/types/database"

interface DepartmentSettingsProps {
  departments: Department[]
}

export function DepartmentSettings({ departments: initialDepartments }: DepartmentSettingsProps) {
  const [departments, setDepartments] = useState(initialDepartments)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingDepartment, setEditingDepartment] = useState<Department | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleCreateDepartment = async (data: { name: string; description: string }) => {
    setIsLoading(true)
    try {
      const supabase = createClient()
      const { data: newDept, error } = await supabase.from("departments").insert(data).select().single()

      if (error) throw error

      setDepartments((prev) => [...prev, newDept])
      setIsCreateDialogOpen(false)
    } catch (error) {
      console.error("Error creating department:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleUpdateDepartment = async (data: Partial<Department>) => {
    if (!editingDepartment) return

    setIsLoading(true)
    try {
      const supabase = createClient()
      const { error } = await supabase.from("departments").update(data).eq("id", editingDepartment.id)

      if (error) throw error

      setDepartments((prev) => prev.map((dept) => (dept.id === editingDepartment.id ? { ...dept, ...data } : dept)))
      setIsEditDialogOpen(false)
      setEditingDepartment(null)
    } catch (error) {
      console.error("Error updating department:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleToggleDepartmentStatus = async (deptId: string, isActive: boolean) => {
    setIsLoading(true)
    try {
      const supabase = createClient()
      const { error } = await supabase.from("departments").update({ is_active: isActive }).eq("id", deptId)

      if (error) throw error

      setDepartments((prev) => prev.map((dept) => (dept.id === deptId ? { ...dept, is_active: isActive } : dept)))
    } catch (error) {
      console.error("Error updating department status:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card className="bg-card border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-card-foreground">Departments</CardTitle>
              <CardDescription className="text-muted-foreground">Manage organizational departments</CardDescription>
            </div>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Department
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-border">
                <DialogHeader>
                  <DialogTitle className="text-card-foreground">Create Department</DialogTitle>
                  <DialogDescription className="text-muted-foreground">
                    Add a new department to the system
                  </DialogDescription>
                </DialogHeader>
                <DepartmentForm
                  onSave={handleCreateDepartment}
                  onCancel={() => setIsCreateDialogOpen(false)}
                  isLoading={isLoading}
                />
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-border">
                <TableHead className="text-card-foreground">Name</TableHead>
                <TableHead className="text-card-foreground">Description</TableHead>
                <TableHead className="text-card-foreground">Status</TableHead>
                <TableHead className="text-card-foreground">Created</TableHead>
                <TableHead className="text-card-foreground">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {departments.map((dept) => (
                <TableRow key={dept.id} className="border-border">
                  <TableCell className="font-medium text-card-foreground">{dept.name}</TableCell>
                  <TableCell className="text-card-foreground">{dept.description || "—"}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={dept.is_active}
                        onCheckedChange={(checked) => handleToggleDepartmentStatus(dept.id, checked)}
                        disabled={isLoading}
                      />
                      <span className="text-sm text-muted-foreground">{dept.is_active ? "Active" : "Inactive"}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-card-foreground">
                    {new Date(dept.created_at).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setEditingDepartment(dept)
                        setIsEditDialogOpen(true)
                      }}
                      className="border-border text-foreground hover:bg-accent bg-transparent"
                    >
                      <Edit className="h-3 w-3 mr-1" />
                      Edit
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit Department Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-card-foreground">Edit Department</DialogTitle>
            <DialogDescription className="text-muted-foreground">Update department information</DialogDescription>
          </DialogHeader>
          {editingDepartment && (
            <DepartmentForm
              department={editingDepartment}
              onSave={handleUpdateDepartment}
              onCancel={() => setIsEditDialogOpen(false)}
              isLoading={isLoading}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

interface DepartmentFormProps {
  department?: Department
  onSave: (data: any) => void
  onCancel: () => void
  isLoading: boolean
}

function DepartmentForm({ department, onSave, onCancel, isLoading }: DepartmentFormProps) {
  const [formData, setFormData] = useState({
    name: department?.name || "",
    description: department?.description || "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSave(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name" className="text-card-foreground">
          Department Name
        </Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
          className="bg-input border-border text-foreground"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description" className="text-card-foreground">
          Description
        </Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
          className="bg-input border-border text-foreground"
        />
      </div>

      <div className="flex justify-end space-x-2 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          className="border-border text-foreground hover:bg-accent bg-transparent"
        >
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading} className="bg-primary hover:bg-primary/90 text-primary-foreground">
          {isLoading ? "Saving..." : department ? "Update" : "Create"}
        </Button>
      </div>
    </form>
  )
}
