"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Download, Upload, Database } from "lucide-react"

export function SystemSettings() {
  const handleExportData = () => {
    // Implementation for data export
    console.log("Exporting data...")
  }

  const handleImportData = () => {
    // Implementation for data import
    console.log("Importing data...")
  }

  const handleBackupDatabase = () => {
    // Implementation for database backup
    console.log("Creating backup...")
  }

  return (
    <div className="space-y-6">
      {/* General Settings */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground">General Settings</CardTitle>
          <CardDescription className="text-muted-foreground">Configure system-wide preferences</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-card-foreground">Auto-assign Approvers</Label>
              <p className="text-sm text-muted-foreground">Automatically assign reports to available approvers</p>
            </div>
            <Switch defaultChecked />
          </div>

          <Separator className="bg-border" />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-card-foreground">Email Notifications</Label>
              <p className="text-sm text-muted-foreground">Send email notifications for approval requests</p>
            </div>
            <Switch defaultChecked />
          </div>

          <Separator className="bg-border" />

          <div className="space-y-2">
            <Label htmlFor="retention" className="text-card-foreground">
              Data Retention Period (days)
            </Label>
            <Input
              id="retention"
              type="number"
              defaultValue="365"
              className="w-32 bg-input border-border text-foreground"
            />
          </div>
        </CardContent>
      </Card>

      {/* Data Management */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground">Data Management</CardTitle>
          <CardDescription className="text-muted-foreground">Import, export, and backup system data</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Button
              variant="outline"
              onClick={handleExportData}
              className="border-border text-foreground hover:bg-accent bg-transparent"
            >
              <Download className="h-4 w-4 mr-2" />
              Export Data
            </Button>
            <Button
              variant="outline"
              onClick={handleImportData}
              className="border-border text-foreground hover:bg-accent bg-transparent"
            >
              <Upload className="h-4 w-4 mr-2" />
              Import Data
            </Button>
          </div>

          <Separator className="bg-border" />

          <div className="space-y-2">
            <Label className="text-card-foreground">Database Backup</Label>
            <p className="text-sm text-muted-foreground">Create a backup of the entire database</p>
            <Button onClick={handleBackupDatabase} className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Database className="h-4 w-4 mr-2" />
              Create Backup
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* System Information */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground">System Information</CardTitle>
          <CardDescription className="text-muted-foreground">Current system status and information</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <Label className="text-card-foreground">Version</Label>
              <p className="text-sm text-muted-foreground">NCP System v1.0.0</p>
            </div>
            <div>
              <Label className="text-card-foreground">Database</Label>
              <p className="text-sm text-muted-foreground">PostgreSQL (Supabase)</p>
            </div>
            <div>
              <Label className="text-card-foreground">Last Backup</Label>
              <p className="text-sm text-muted-foreground">Never</p>
            </div>
            <div>
              <Label className="text-card-foreground">Uptime</Label>
              <p className="text-sm text-muted-foreground">24 hours</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
