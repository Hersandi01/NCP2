# User Guide - NCP Management System

## Panduan Lengkap Penggunaan Sistem

### Daftar Isi
1. [Pengenalan Sistem](#pengenalan-sistem)
2. [Login dan Akses](#login-dan-akses)
3. [Dashboard Overview](#dashboard-overview)
4. [Panduan per Role](#panduan-per-role)
5. [Workflow Approval](#workflow-approval)
6. [Fitur Lanjutan](#fitur-lanjutan)
7. [FAQ](#faq)

## Pengenalan Sistem

NCP (Non-Conformance Product) Management System adalah platform digital untuk mengelola laporan ketidaksesuaian produk dalam proses manufaktur. Sistem ini dirancang dengan workflow approval bertingkat untuk memastikan quality assurance yang terstruktur.

### Fitur Utama
- ✅ Pembuatan laporan NCP digital
- ✅ Workflow approval 4 tingkat
- ✅ Dashboard analytics real-time
- ✅ Audit trail lengkap
- ✅ Notifikasi otomatis
- ✅ Export data CSV
- ✅ Upload attachment file

## Login dan Akses

### Cara Login
1. Buka aplikasi di browser
2. Masukkan email dan password
3. Klik "Sign In"
4. Sistem akan redirect ke dashboard sesuai role

### Lupa Password
1. Klik "Forgot Password?" di halaman login
2. Masukkan email terdaftar
3. Cek email untuk link reset password
4. Ikuti instruksi di email

### Keamanan Akun
- Gunakan password yang kuat (min 8 karakter)
- Logout setelah selesai menggunakan sistem
- Jangan share kredensial login
- Laporkan aktivitas mencurigakan ke admin

## Dashboard Overview

### Layout Utama
- **Header**: Logo, notifikasi, profile menu
- **Sidebar**: Menu navigasi sesuai role
- **Main Content**: Konten halaman aktif
- **Footer**: Informasi sistem dan support

### Navigasi Sidebar
Menu yang tersedia berbeda untuk setiap role:
- 🏠 **Dashboard**: Overview dan statistik
- 📋 **Reports**: Manajemen laporan NCP
- ✅ **Approvals**: Proses persetujuan
- 📊 **Analytics**: Analisis dan metrics
- 👥 **Users**: Manajemen pengguna (Superadmin)
- ⚙️ **Settings**: Pengaturan sistem
- 🔔 **Notifications**: Notifikasi sistem

## Panduan per Role

### 1. QA Inspector

#### Tugas Utama
- Membuat laporan NCP baru
- Mengedit laporan draft
- Upload attachment pendukung
- Monitor status laporan

#### Cara Membuat Laporan NCP
1. **Akses Menu Reports**
   - Klik "Reports" di sidebar
   - Klik tombol "Create New Report"

2. **Isi Form Laporan**
   - **Basic Information**:
     - Title: Judul singkat dan jelas
     - Description: Deskripsi detail masalah
     - Department: Pilih department terkait
     - Priority: High/Medium/Low
   
   - **Product Information**:
     - Product Name: Nama produk
     - Batch Number: Nomor batch
     - Quantity: Jumlah produk bermasalah
   
   - **Issue Details**:
     - Category: Kategori masalah
     - Root Cause: Analisis akar masalah
     - Impact: Dampak terhadap operasional

3. **Upload Attachment**
   - Klik "Upload Files"
   - Pilih file pendukung (foto, dokumen)
   - Max 10MB per file
   - Format: PDF, JPG, PNG, DOC

4. **Save atau Submit**
   - **Save as Draft**: Simpan untuk dilanjutkan nanti
   - **Submit**: Kirim ke workflow approval

#### Tips untuk QA Inspector
- Gunakan foto berkualitas tinggi untuk dokumentasi
- Isi deskripsi sejelas mungkin
- Pastikan root cause analysis akurat
- Simpan draft jika belum lengkap

### 2. QA Leader

#### Tugas Utama
- Review laporan dari QA Inspector
- Approve/reject dengan komentar
- Assign approver berikutnya
- Monitor team performance

#### Cara Review Laporan
1. **Akses Pending Approvals**
   - Klik "Approvals" di sidebar
   - Tab "Pending" menampilkan laporan menunggu review

2. **Review Detail Laporan**
   - Klik laporan untuk melihat detail
   - Periksa semua informasi dan attachment
   - Baca deskripsi dan analisis root cause

3. **Buat Keputusan**
   - **Approve**: Jika laporan sudah sesuai
     - Tambahkan komentar/rekomendasi
     - Pilih Team Leader untuk review berikutnya
     - Klik "Approve"
   
   - **Reject**: Jika perlu perbaikan
     - Jelaskan alasan penolakan
     - Berikan guidance untuk perbaikan
     - Klik "Reject"

#### Best Practices QA Leader
- Review dalam 24 jam setelah assignment
- Berikan feedback konstruktif
- Pastikan dokumentasi lengkap
- Koordinasi dengan team untuk improvement

### 3. Team Leader

#### Tugas Utama
- Review laporan dari QA Leader
- Evaluasi dampak operasional
- Koordinasi dengan team terkait
- Assign ke Process Lead

#### Workflow Review
1. **Evaluasi Teknis**
   - Analisis dampak terhadap produksi
   - Cek kesesuaian dengan SOP
   - Validasi root cause analysis

2. **Koordinasi Team**
   - Diskusi dengan anggota team
   - Konfirmasi tindakan korektif
   - Pastikan resource tersedia

3. **Keputusan Approval**
   - Approve jika feasible untuk implementasi
   - Reject jika perlu analisis lebih lanjut
   - Assign ke Process Lead yang tepat

### 4. Process Lead

#### Tugas Utama
- Review aspek teknis dan proses
- Evaluasi implementasi solusi
- Koordinasi lintas department
- Final technical approval

#### Focus Area Review
1. **Technical Feasibility**
   - Analisis solusi yang diusulkan
   - Evaluasi impact terhadap proses
   - Cek compliance dengan standard

2. **Resource Planning**
   - Estimasi waktu implementasi
   - Kebutuhan material/tools
   - Training requirement

3. **Risk Assessment**
   - Identifikasi potential risk
   - Mitigation strategy
   - Contingency planning

### 5. QA Manager

#### Tugas Utama
- Final approval authority
- Strategic decision making
- System oversight
- Quality metrics monitoring

#### Final Review Process
1. **Strategic Evaluation**
   - Alignment dengan quality objectives
   - Impact terhadap customer satisfaction
   - Cost-benefit analysis

2. **Decision Making**
   - Final approve/reject
   - Strategic recommendations
   - Policy implications

3. **Follow-up Actions**
   - Implementation monitoring
   - Effectiveness evaluation
   - Continuous improvement

### 6. Superadmin

#### Tugas Utama
- User management
- System configuration
- Data oversight
- Technical support

#### User Management
1. **Create New User**
   - Akses menu "Users"
   - Klik "Add New User"
   - Isi informasi lengkap
   - Assign role dan department

2. **Manage Existing Users**
   - Edit profile information
   - Change role assignments
   - Activate/deactivate accounts
   - Reset passwords

#### System Settings
1. **Department Management**
   - Add/edit departments
   - Set department hierarchy
   - Assign department heads

2. **System Configuration**
   - Approval workflow settings
   - Notification preferences
   - Export configurations

## Workflow Approval

### Alur Proses Lengkap

\`\`\`
1. QA Inspector → Create Report
2. QA Leader → Review & Approve/Reject
3. Team Leader → Technical Review
4. Process Lead → Implementation Review
5. QA Manager → Final Approval
\`\`\`

### Status Laporan
- **Draft**: Belum disubmit
- **Submitted**: Menunggu QA Leader
- **QA Leader Review**: Sedang direview QA Leader
- **Team Leader Review**: Sedang direview Team Leader
- **Process Lead Review**: Sedang direview Process Lead
- **QA Manager Review**: Sedang direview QA Manager
- **Approved**: Disetujui final
- **Rejected**: Ditolak (kembali ke creator)

### Timeline Approval
- **QA Leader**: 24 jam
- **Team Leader**: 48 jam
- **Process Lead**: 48 jam
- **QA Manager**: 72 jam

### Notifikasi Otomatis
- Email notification untuk setiap assignment
- In-app notification untuk status update
- Reminder untuk overdue approvals
- Summary report mingguan

## Fitur Lanjutan

### Analytics Dashboard

#### Metrics Tersedia
- **Summary Cards**: Total reports, pending approvals, monthly stats
- **Trend Charts**: Monthly report trends, approval rates
- **Department Analysis**: Performance per department
- **User Activity**: Individual performance metrics

#### Cara Menggunakan Analytics
1. Akses menu "Analytics"
2. Pilih date range untuk analisis
3. Filter berdasarkan department/status
4. Export chart sebagai image/PDF

### Export Data

#### Export CSV Reports
1. Akses menu "Reports"
2. Set filter sesuai kebutuhan
3. Klik "Export CSV"
4. File akan didownload otomatis

#### Data yang Diekspor
- Report details lengkap
- Approval history
- Timestamps semua aktivitas
- User information

### Advanced Search

#### Search Options
- **Text Search**: Cari berdasarkan title/description
- **Status Filter**: Filter berdasarkan status
- **Date Range**: Filter berdasarkan tanggal
- **Department**: Filter berdasarkan department
- **Priority**: Filter berdasarkan prioritas

#### Tips Pencarian Efektif
- Gunakan keyword spesifik
- Kombinasikan multiple filters
- Simpan frequent searches
- Gunakan wildcard (*) untuk partial match

### Notification Management

#### Jenis Notifikasi
- **Assignment**: Laporan baru untuk review
- **Status Update**: Perubahan status laporan
- **Reminder**: Overdue approvals
- **System**: Maintenance dan updates

#### Pengaturan Notifikasi
1. Akses "Settings" → "Notifications"
2. Pilih jenis notifikasi yang diinginkan
3. Set frequency (immediate/daily/weekly)
4. Save preferences

## FAQ

### Pertanyaan Umum

**Q: Bagaimana cara mengubah password?**
A: Akses Profile → Settings → Change Password. Masukkan password lama dan password baru.

**Q: Laporan saya ditolak, apa yang harus dilakukan?**
A: Baca komentar dari approver, lakukan perbaikan sesuai feedback, kemudian submit ulang.

**Q: Bisakah mengedit laporan yang sudah disubmit?**
A: Tidak. Laporan yang sudah disubmit hanya bisa diedit jika ditolak dan kembali ke status draft.

**Q: Bagaimana cara upload file besar?**
A: Maksimal file size adalah 10MB. Untuk file lebih besar, kompres terlebih dahulu atau split menjadi beberapa file.

**Q: Tidak menerima notifikasi email?**
A: Cek spam folder, pastikan email settings benar di profile, atau hubungi admin sistem.

### Troubleshooting

**Problem: Tidak bisa login**
- Pastikan email dan password benar
- Cek caps lock
- Clear browser cache
- Hubungi admin jika masih bermasalah

**Problem: Halaman loading lambat**
- Refresh browser
- Cek koneksi internet
- Clear browser cache
- Gunakan browser yang supported

**Problem: File tidak bisa diupload**
- Cek ukuran file (max 10MB)
- Pastikan format file supported
- Coba browser lain
- Hubungi support jika persisten

### Kontak Support

**Technical Support**
- Email: support@company.com
- Phone: +62-xxx-xxxx-xxxx
- Working Hours: 08:00 - 17:00 WIB

**System Admin**
- Email: admin@company.com
- Internal Extension: xxx

**Training & Documentation**
- Email: training@company.com
- Knowledge Base: [internal-link]

---

**Catatan**: Panduan ini akan diupdate secara berkala. Pastikan selalu menggunakan versi terbaru.
