# ❓ Frequently Asked Questions (FAQ)

## 🔐 **Tentang Akun dan Login**

### Q: Bagaimana cara reset password?
**A:** 
1. Di halaman login, klik "Forgot Password"
2. Masukkan email Anda
3. Cek email untuk link reset password
4. Klik link dan buat password baru

### Q: Mengapa saya tidak bisa login?
**A:** Kemungkinan penyebab:
- Email/password salah
- Akun belum diverifikasi
- Akun dinonaktifkan oleh admin
- Masalah koneksi internet

### Q: Bisakah saya mengubah email akun?
**A:** Ya, hubungi Superadmin untuk mengubah email akun Anda.

---

## 📝 **Tentang Laporan NCP**

### Q: Apa itu NCP Number dan bagaimana formatnya?
**A:** NCP Number adalah nomor unik untuk setiap laporan dengan format: `NCP-YYYY-NNNN`
- YYYY = Tahun
- NNNN = Nomor urut (0001, 0002, dst)
- Contoh: NCP-2024-0001

### Q: Bisakah saya edit laporan setelah disubmit?
**A:** Tidak. Setelah disubmit untuk approval, laporan tidak bisa diedit. Anda hanya bisa edit laporan dengan status "Draft".

### Q: Berapa ukuran maksimal file yang bisa diupload?
**A:** Maksimal 10MB per file. Format yang didukung: JPG, PNG, PDF, DOC, DOCX.

### Q: Apa yang terjadi jika laporan ditolak?
**A:** Laporan akan kembali ke pembuat dengan status "Rejected". Anda perlu membuat laporan baru dengan perbaikan.

---

## ✅ **Tentang Proses Approval**

### Q: Berapa lama proses approval?
**A:** Tidak ada batas waktu otomatis. Tergantung pada kebijakan perusahaan dan ketersediaan approver.

### Q: Bisakah saya melihat siapa saja yang sudah approve?
**A:** Ya, di halaman detail laporan ada section "Approval History" yang menampilkan semua approval dengan timestamp.

### Q: Apa yang terjadi jika approver tidak tersedia?
**A:** Superadmin bisa reassign approval ke approver lain atau mengubah workflow sesuai kebutuhan.

### Q: Bisakah approval diubah setelah disubmit?
**A:** Tidak. Keputusan approval bersifat final dan tidak bisa diubah.

---

## 👥 **Tentang Peran dan Akses**

### Q: Apa perbedaan setiap role?
**A:**
- **Superadmin**: Akses penuh ke semua fitur
- **QA Manager**: Approve final, lihat semua laporan
- **QA Leader**: Approve level 1, manage QA Inspector
- **Team Leader**: Approve level 2, manage tim
- **Process Lead**: Approve level 3, manage proses
- **QA Inspector**: Buat laporan, lihat laporan sendiri

### Q: Bisakah saya memiliki multiple role?
**A:** Tidak. Setiap user hanya bisa memiliki satu role aktif.

### Q: Bagaimana cara mengubah role?
**A:** Hanya Superadmin yang bisa mengubah role user lain.

---

## 📊 **Tentang Dashboard dan Analytics**

### Q: Mengapa grafik saya kosong?
**A:** Kemungkinan penyebab:
- Belum ada data laporan
- Filter tanggal terlalu sempit
- Anda tidak memiliki akses ke data tersebut

### Q: Bisakah saya export data dalam format lain selain CSV?
**A:** Saat ini hanya mendukung CSV. Anda bisa convert CSV ke Excel atau format lain.

### Q: Seberapa sering data dashboard diupdate?
**A:** Data dashboard diupdate secara real-time setiap ada perubahan.

---

## 🔧 **Masalah Teknis**

### Q: Website loading lambat, apa yang harus dilakukan?
**A:**
1. Cek koneksi internet
2. Clear browser cache
3. Coba browser lain
4. Hubungi IT support jika masih lambat

### Q: Fitur tertentu tidak berfungsi, bagaimana?
**A:**
1. Refresh halaman
2. Logout dan login kembali
3. Clear browser cache
4. Coba browser lain
5. Hubungi admin jika masih bermasalah

### Q: Bisakah saya menggunakan sistem di mobile?
**A:** Ya, sistem responsive dan bisa digunakan di mobile browser. Namun untuk pengalaman terbaik disarankan menggunakan desktop/laptop.

---

## 📱 **Tips dan Trik**

### Q: Bagaimana cara mencari laporan dengan cepat?
**A:**
- Gunakan search box di halaman Reports
- Filter berdasarkan status, tanggal, atau department
- Bookmark laporan penting
- Gunakan NCP Number untuk pencarian spesifik

### Q: Bagaimana cara backup data?
**A:**
- Export CSV secara berkala
- Superadmin bisa request database backup
- Simpan file attachment secara terpisah

### Q: Ada shortcut keyboard?
**A:**
- Ctrl+S: Save draft (di form laporan)
- Ctrl+Enter: Submit form
- Esc: Close modal/popup
- Tab: Navigate antar field

---

## 🚨 **Keamanan dan Privacy**

### Q: Apakah data saya aman?
**A:** Ya, sistem menggunakan:
- Enkripsi HTTPS
- Row Level Security di database
- Authentication yang aman
- Audit trail untuk semua aktivitas

### Q: Siapa saja yang bisa melihat laporan saya?
**A:** Tergantung role dan department:
- Laporan Anda: Anda + approver + Superadmin
- Laporan department: Semua user di department yang sama
- Semua laporan: Hanya Superadmin dan QA Manager

### Q: Bisakah saya menghapus laporan?
**A:** Tidak. Untuk audit trail, laporan tidak bisa dihapus. Hanya bisa diubah statusnya oleh Superadmin.

---

## 📞 **Kontak dan Support**

### Q: Kemana saya harus melaporkan bug atau masalah?
**A:**
1. Hubungi Superadmin sistem
2. Email ke IT support perusahaan
3. Buat ticket di sistem internal
4. Dokumentasikan langkah yang menyebabkan error

### Q: Bagaimana cara request fitur baru?
**A:**
1. Diskusikan dengan Superadmin
2. Buat proposal fitur yang detail
3. Submit ke management untuk approval
4. Koordinasi dengan IT development team

### Q: Ada training untuk sistem ini?
**A:** Hubungi HR atau IT department untuk jadwal training. Dokumentasi lengkap tersedia di folder `docs/`.

---

**💡 Tip:** Bookmark halaman FAQ ini untuk referensi cepat!
