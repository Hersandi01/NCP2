# 📋 Panduan Lengkap Sistem NCP Management - Untuk Pemula

## 🎯 Apa itu Sistem NCP Management?

Sistem NCP (Non-Conformance Product) Management adalah aplikasi web untuk mengelola laporan produk yang tidak sesuai standar di perusahaan manufaktur. Sistem ini membantu:

- ✅ Membuat laporan ketidaksesuaian produk
- ✅ Mengelola proses persetujuan berlapis
- ✅ Melacak status laporan secara real-time
- ✅ Menganalisis data dengan dashboard
- ✅ Mengelola pengguna dan departemen

---

## 🚀 Langkah 1: Persiapan Awal

### A. Yang Anda Butuhkan:
1. **Komputer/Laptop** dengan koneksi internet
2. **Browser modern** (Chrome, Firefox, Safari, Edge)
3. **Akun Vercel** (gratis) - untuk hosting
4. **Akun Supabase** (gratis) - untuk database

### B. Buat Akun yang Diperlukan:

#### 1. Buat Akun Vercel:
- Kunjungi: https://vercel.com
- Klik "Sign Up" 
- Pilih "Continue with GitHub" (atau email)
- Ikuti instruksi pendaftaran

#### 2. Buat Akun Supabase:
- Kunjungi: https://supabase.com
- Klik "Start your project"
- Pilih "Sign in with GitHub" (atau email)
- Ikuti instruksi pendaftaran

---

## 🛠️ Langkah 2: Setup Database (Supabase)

### A. Buat Project Baru di Supabase:
1. Login ke dashboard Supabase
2. Klik "New Project"
3. Isi informasi:
   - **Name**: `ncp-management-system`
   - **Database Password**: Buat password yang kuat (catat baik-baik!)
   - **Region**: Pilih yang terdekat dengan lokasi Anda
4. Klik "Create new project"
5. Tunggu 2-3 menit hingga project siap

### B. Setup Database Schema:
1. Di dashboard Supabase, klik tab "SQL Editor"
2. Klik "New Query"
3. Copy-paste script dari file `scripts/001_create_database_schema.sql`
4. Klik "Run" (tombol play)
5. Ulangi untuk file:
   - `scripts/002_create_functions_and_triggers.sql`
   - `scripts/003_seed_initial_data.sql`
   - `scripts/004_create_workflow_functions.sql`

### C. Catat Informasi Penting:
1. Di dashboard Supabase, klik "Settings" → "API"
2. Catat informasi berikut:
   - **Project URL**: `https://xxxxx.supabase.co`
   - **anon public key**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`
   - **service_role key**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

---

## 🌐 Langkah 3: Deploy ke Vercel

### A. Upload Project ke Vercel:
1. Login ke dashboard Vercel
2. Klik "Add New..." → "Project"
3. Pilih "Import Git Repository"
4. Upload file ZIP project atau connect dari GitHub
5. Klik "Deploy"

### B. Setup Environment Variables:
1. Setelah deploy selesai, klik "Settings"
2. Klik "Environment Variables"
3. Tambahkan variabel berikut:

\`\`\`
NEXT_PUBLIC_SUPABASE_URL = https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL = http://localhost:3000/auth/callback
\`\`\`

4. Klik "Save"
5. Klik "Redeploy" untuk menerapkan perubahan

---

## 👤 Langkah 4: Buat Akun Pengguna Pertama

### A. Akses Aplikasi:
1. Buka URL aplikasi Anda (dari Vercel dashboard)
2. Klik "Sign Up" di halaman login

### B. Daftar sebagai Superadmin:
1. Isi form pendaftaran:
   - **Email**: email@anda.com
   - **Password**: password yang kuat
   - **Full Name**: Nama Lengkap Anda
   - **Role**: Pilih "Superadmin"
   - **Department**: IT atau sesuai kebutuhan
2. Klik "Sign Up"
3. Cek email untuk verifikasi (jika diminta)

---

## 🎮 Langkah 5: Cara Menggunakan Sistem

### A. Login Pertama Kali:
1. Buka aplikasi di browser
2. Masukkan email dan password
3. Klik "Sign In"
4. Anda akan masuk ke Dashboard utama

### B. Navigasi Utama:

#### 📊 **Dashboard**
- Melihat ringkasan statistik
- Grafik laporan bulanan
- Status approval terbaru

#### 📝 **Reports (Laporan)**
- **View All Reports**: Melihat semua laporan
- **Create New Report**: Membuat laporan baru
- **Filter**: Cari berdasarkan status, tanggal, dll

#### ✅ **Approvals (Persetujuan)**
- **Pending**: Laporan yang menunggu persetujuan Anda
- **Completed**: Laporan yang sudah Anda setujui/tolak

#### 📈 **Analytics**
- Grafik detail per departemen
- Trend bulanan dan tahunan
- Export data ke CSV

#### 👥 **Users (Pengguna)** - Khusus Superadmin
- Tambah pengguna baru
- Edit role dan departemen
- Nonaktifkan pengguna

#### ⚙️ **Settings (Pengaturan)**
- Kelola departemen
- Pengaturan sistem
- Konfigurasi workflow

---

## 📋 Langkah 6: Membuat Laporan NCP Pertama

### A. Buat Laporan Baru:
1. Klik menu "Reports" → "Create New Report"
2. Isi form dengan lengkap:

**Informasi Dasar:**
- **Product Name**: Nama produk bermasalah
- **Product Code**: Kode produk (opsional)
- **Batch/Lot Number**: Nomor batch produk
- **Quantity**: Jumlah produk bermasalah
- **Department**: Pilih departemen terkait

**Detail Masalah:**
- **Non-Conformance Type**: Pilih jenis masalah
- **Description**: Jelaskan masalah secara detail
- **Root Cause**: Analisis penyebab masalah
- **Corrective Action**: Tindakan perbaikan yang diambil

**Lampiran:**
- Upload foto produk bermasalah (opsional)
- Upload dokumen pendukung (opsional)

3. Pilih tindakan:
   - **Save as Draft**: Simpan sebagai draft (bisa diedit lagi)
   - **Submit for Approval**: Kirim untuk proses persetujuan

### B. Melacak Status Laporan:
1. Klik menu "Reports"
2. Cari laporan Anda di daftar
3. Klik nama laporan untuk melihat detail
4. Lihat status di bagian "Approval Workflow"

---

## ✅ Langkah 7: Proses Persetujuan (Untuk Approver)

### A. Melihat Laporan yang Perlu Disetujui:
1. Klik menu "Approvals"
2. Tab "Pending" menampilkan laporan yang menunggu
3. Klik laporan untuk melihat detail

### B. Memberikan Persetujuan:
1. Baca detail laporan dengan teliti
2. Scroll ke bagian "Approval Action"
3. Pilih tindakan:
   - **Approve**: Setujui dan lanjut ke tahap berikutnya
   - **Reject**: Tolak dengan alasan
4. Isi komentar (wajib)
5. Jika approve, pilih approver berikutnya
6. Klik "Submit Decision"

---

## 📊 Langkah 8: Melihat Analytics dan Reports

### A. Dashboard Analytics:
1. Klik menu "Analytics"
2. Lihat berbagai grafik:
   - **Approval Rate**: Persentase laporan yang disetujui
   - **Monthly Trends**: Trend laporan per bulan
   - **Department Breakdown**: Laporan per departemen
   - **Status Distribution**: Distribusi status laporan

### B. Export Data:
1. Di halaman "Reports", klik "Export CSV"
2. Pilih filter yang diinginkan
3. File CSV akan didownload otomatis

---

## 👥 Langkah 9: Mengelola Pengguna (Superadmin)

### A. Tambah Pengguna Baru:
1. Klik menu "Users"
2. Klik "Add New User"
3. Isi informasi pengguna:
   - **Email**: Email pengguna baru
   - **Full Name**: Nama lengkap
   - **Role**: Pilih peran (QA Inspector, QA Leader, dll)
   - **Department**: Pilih departemen
4. Klik "Add User"
5. Pengguna akan menerima email untuk set password

### B. Edit Pengguna:
1. Di daftar pengguna, klik tombol "Edit"
2. Ubah informasi yang diperlukan
3. Klik "Save Changes"

---

## 🔧 Troubleshooting - Masalah Umum

### ❌ **Tidak Bisa Login**
**Solusi:**
- Pastikan email dan password benar
- Cek apakah akun sudah diverifikasi via email
- Coba reset password jika lupa

### ❌ **Error saat Submit Laporan**
**Solusi:**
- Pastikan semua field wajib sudah diisi
- Cek koneksi internet
- Refresh halaman dan coba lagi

### ❌ **Tidak Menerima Notifikasi**
**Solusi:**
- Cek folder spam di email
- Pastikan email address benar di profile
- Hubungi admin untuk cek pengaturan

### ❌ **Grafik Tidak Muncul**
**Solusi:**
- Refresh halaman
- Cek apakah ada data laporan
- Coba browser lain

### ❌ **Upload File Gagal**
**Solusi:**
- Pastikan ukuran file < 10MB
- Format file yang didukung: JPG, PNG, PDF, DOC
- Coba compress file jika terlalu besar

---

## 📞 Bantuan dan Support

### 🆘 **Butuh Bantuan?**
1. **Dokumentasi Teknis**: Baca file `README.md`
2. **API Documentation**: Lihat `docs/API_DOCUMENTATION.md`
3. **User Guide Detail**: Baca `docs/USER_GUIDE.md`

### 📧 **Kontak Support**
- Email admin sistem Anda
- Buat ticket di sistem internal perusahaan
- Hubungi IT Support

---

## 🎉 Selamat!

Anda telah berhasil setup dan menggunakan Sistem NCP Management! 

**Tips untuk Penggunaan Optimal:**
- ✅ Selalu isi laporan dengan lengkap dan jelas
- ✅ Upload foto/dokumen pendukung jika memungkinkan
- ✅ Berikan komentar yang konstruktif saat approval
- ✅ Gunakan filter untuk mencari laporan dengan cepat
- ✅ Cek dashboard secara berkala untuk monitoring

**Selamat menggunakan sistem! 🚀**
