# Deployment Guide

## Overview

Panduan lengkap untuk deploy NCP Management System ke production environment menggunakan Vercel dan Supabase.

## Prerequisites

### Required Accounts
- [Vercel Account](https://vercel.com) (untuk hosting)
- [Supabase Account](https://supabase.com) (untuk database)
- [GitHub Account](https://github.com) (untuk source control)

### Local Development Setup
- Node.js 18+ 
- npm atau yarn
- Git

## Production Deployment

### 1. Supabase Setup

#### Create Supabase Project
1. Login ke [Supabase Dashboard](https://app.supabase.com)
2. Klik "New Project"
3. Isi project details:
   - **Name**: NCP Management System
   - **Database Password**: Generate strong password
   - **Region**: Pilih region terdekat
4. Tunggu project selesai dibuat (~2 menit)

#### Database Configuration
1. **Run Migration Scripts**
   - Akses SQL Editor di Supabase Dashboard
   - Copy-paste dan execute scripts secara berurutan:
     - `scripts/001_create_database_schema.sql`
     - `scripts/002_create_functions_and_triggers.sql`
     - `scripts/003_seed_initial_data.sql`
     - `scripts/004_create_workflow_functions.sql`

2. **Configure Authentication**
   - Akses Authentication → Settings
   - Enable Email authentication
   - Set Site URL: `https://your-domain.vercel.app`
   - Configure email templates (optional)

3. **Setup Row Level Security**
   - Pastikan semua RLS policies sudah aktif
   - Test dengan sample data

#### Get Supabase Credentials
\`\`\`bash
# Dari Supabase Dashboard → Settings → API
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
\`\`\`

### 2. Vercel Deployment

#### Connect Repository
1. Push code ke GitHub repository
2. Login ke [Vercel Dashboard](https://vercel.com/dashboard)
3. Klik "New Project"
4. Import dari GitHub repository
5. Configure project settings:
   - **Framework Preset**: Next.js
   - **Root Directory**: ./
   - **Build Command**: `npm run build`
   - **Output Directory**: .next

#### Environment Variables
Tambahkan environment variables di Vercel:

\`\`\`bash
# Supabase Configuration
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

# Optional: Custom configurations
NEXT_PUBLIC_APP_NAME=NCP Management System
NEXT_PUBLIC_APP_VERSION=1.0.0
\`\`\`

#### Deploy
1. Klik "Deploy"
2. Tunggu build process selesai
3. Vercel akan provide production URL

### 3. Post-Deployment Configuration

#### Update Supabase Settings
1. **Authentication Settings**
   - Site URL: `https://your-app.vercel.app`
   - Redirect URLs: `https://your-app.vercel.app/auth/callback`

2. **CORS Configuration**
   - Tambahkan domain production ke allowed origins

#### Create Initial Superadmin
\`\`\`sql
-- Execute di Supabase SQL Editor
INSERT INTO auth.users (
  id,
  email,
  encrypted_password,
  email_confirmed_at,
  created_at,
  updated_at
) VALUES (
  gen_random_uuid(),
  'admin@yourcompany.com',
  crypt('your-secure-password', gen_salt('bf')),
  now(),
  now(),
  now()
);

-- Create profile for superadmin
INSERT INTO profiles (
  id,
  email,
  name,
  role,
  department,
  is_active
) VALUES (
  (SELECT id FROM auth.users WHERE email = 'admin@yourcompany.com'),
  'admin@yourcompany.com',
  'System Administrator',
  'superadmin',
  'IT',
  true
);
\`\`\`

## Custom Domain Setup

### 1. Domain Configuration
1. **Vercel Dashboard**
   - Akses project settings
   - Klik "Domains"
   - Add custom domain: `ncp.yourcompany.com`

2. **DNS Configuration**
   - Tambahkan CNAME record di DNS provider:
   \`\`\`
   CNAME ncp cname.vercel-dns.com
   \`\`\`

3. **SSL Certificate**
   - Vercel akan auto-generate SSL certificate
   - Tunggu propagasi DNS (~24 jam)

### 2. Update Application URLs
\`\`\`bash
# Update environment variables
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXTAUTH_URL=https://ncp.yourcompany.com
\`\`\`

## Environment-Specific Configurations

### Development Environment
\`\`\`bash
# .env.local
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL=http://localhost:3000
\`\`\`

### Staging Environment
\`\`\`bash
# Vercel staging environment variables
NEXT_PUBLIC_SUPABASE_URL=https://staging-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=staging-anon-key
SUPABASE_SERVICE_ROLE_KEY=staging-service-role-key
\`\`\`

### Production Environment
\`\`\`bash
# Vercel production environment variables
NEXT_PUBLIC_SUPABASE_URL=https://prod-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=prod-anon-key
SUPABASE_SERVICE_ROLE_KEY=prod-service-role-key
\`\`\`

## Performance Optimization

### 1. Vercel Configuration
\`\`\`javascript
// next.config.mjs
/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    optimizePackageImports: ['@supabase/supabase-js']
  },
  images: {
    domains: ['your-project.supabase.co'],
    formats: ['image/webp', 'image/avif']
  },
  compress: true,
  poweredByHeader: false
}

export default nextConfig
\`\`\`

### 2. Database Optimization
\`\`\`sql
-- Create indexes for better performance
CREATE INDEX idx_ncp_reports_status ON ncp_reports(status);
CREATE INDEX idx_ncp_reports_created_at ON ncp_reports(created_at);
CREATE INDEX idx_ncp_reports_department ON ncp_reports(department);
CREATE INDEX idx_ncp_approvals_assigned_to ON ncp_approvals(assigned_to);
CREATE INDEX idx_audit_logs_table_name ON audit_logs(table_name);
\`\`\`

### 3. Caching Strategy
- Static pages: ISR dengan revalidation 3600s
- API routes: Cache dengan stale-while-revalidate
- Database queries: Supabase built-in caching

## Monitoring & Analytics

### 1. Vercel Analytics
\`\`\`bash
# Install Vercel Analytics
npm install @vercel/analytics

# Add to layout.tsx
import { Analytics } from '@vercel/analytics/react'
\`\`\`

### 2. Error Monitoring
\`\`\`bash
# Install Sentry (optional)
npm install @sentry/nextjs

# Configure sentry.client.config.js
import * as Sentry from "@sentry/nextjs"

Sentry.init({
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  environment: process.env.NODE_ENV
})
\`\`\`

### 3. Database Monitoring
- Supabase Dashboard → Logs
- Monitor query performance
- Set up alerts untuk high usage

## Backup & Recovery

### 1. Database Backup
\`\`\`bash
# Automated daily backups (Supabase Pro)
# Manual backup via pg_dump
pg_dump -h db.your-project.supabase.co -U postgres -d postgres > backup.sql
\`\`\`

### 2. Code Backup
- GitHub repository sebagai source of truth
- Vercel automatic deployments dari Git
- Tag releases untuk version control

### 3. Recovery Procedures
1. **Database Recovery**
   - Restore dari Supabase backup
   - Re-run migration scripts jika perlu

2. **Application Recovery**
   - Rollback ke previous deployment di Vercel
   - Fix issues dan redeploy

## Security Checklist

### 1. Environment Variables
- ✅ Semua secrets di environment variables
- ✅ Tidak ada hardcoded credentials
- ✅ Different keys untuk staging/production

### 2. Database Security
- ✅ Row Level Security (RLS) enabled
- ✅ Proper role-based permissions
- ✅ Regular security updates

### 3. Application Security
- ✅ HTTPS enforced
- ✅ Secure headers configured
- ✅ Input validation implemented
- ✅ Authentication middleware active

### 4. Access Control
- ✅ Strong password policies
- ✅ Role-based access control
- ✅ Audit logging enabled
- ✅ Regular access reviews

## Maintenance

### 1. Regular Updates
\`\`\`bash
# Update dependencies monthly
npm update
npm audit fix

# Update Supabase client
npm install @supabase/supabase-js@latest
\`\`\`

### 2. Database Maintenance
\`\`\`sql
-- Monthly cleanup old audit logs
DELETE FROM audit_logs 
WHERE created_at < NOW() - INTERVAL '1 year';

-- Analyze table statistics
ANALYZE ncp_reports;
ANALYZE ncp_approvals;
\`\`\`

### 3. Performance Monitoring
- Monitor Vercel function execution times
- Check Supabase query performance
- Review error logs weekly
- Monitor storage usage

## Troubleshooting

### Common Issues

#### Build Failures
\`\`\`bash
# Clear Vercel cache
vercel --prod --force

# Check build logs
vercel logs your-deployment-url
\`\`\`

#### Database Connection Issues
\`\`\`bash
# Test connection
npx supabase status
npx supabase db ping
\`\`\`

#### Authentication Problems
1. Check Supabase Auth settings
2. Verify redirect URLs
3. Test with different browsers
4. Check CORS configuration

### Support Contacts

**Vercel Support**
- Documentation: https://vercel.com/docs
- Community: https://github.com/vercel/vercel/discussions

**Supabase Support**
- Documentation: https://supabase.com/docs
- Community: https://github.com/supabase/supabase/discussions

---

**Deployment Checklist**
- [ ] Supabase project created
- [ ] Database migrations executed
- [ ] Environment variables configured
- [ ] Vercel project deployed
- [ ] Custom domain configured (optional)
- [ ] Initial superadmin created
- [ ] Authentication tested
- [ ] Performance optimized
- [ ] Monitoring setup
- [ ] Backup strategy implemented
