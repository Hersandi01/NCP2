# API Documentation

## Overview

NCP Management System menyediakan RESTful API untuk semua operasi sistem. API menggunakan authentication berbasis session dengan Supabase Auth.

## Authentication

### Headers Required
\`\`\`
Authorization: Bearer <supabase_access_token>
Content-Type: application/json
\`\`\`

### Authentication Flow
1. Login melalui `/api/auth/login`
2. Receive access token
3. Include token dalam semua API calls
4. Token akan auto-refresh oleh Supabase client

## Base URL
\`\`\`
Production: https://your-domain.com/api
Development: http://localhost:3000/api
\`\`\`

## Endpoints

### Authentication

#### POST /api/auth/login
Login user dengan email dan password.

**Request Body:**
\`\`\`json
{
  "email": "user@example.com",
  "password": "password123"
}
\`\`\`

**Response:**
\`\`\`json
{
  "success": true,
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "role": "qa_inspector"
  },
  "session": {
    "access_token": "jwt_token",
    "refresh_token": "refresh_token"
  }
}
\`\`\`

#### POST /api/auth/logout
Logout user dan invalidate session.

**Response:**
\`\`\`json
{
  "success": true,
  "message": "Logged out successfully"
}
\`\`\`

### Reports

#### GET /api/reports
Mendapatkan daftar laporan NCP dengan filtering dan pagination.

**Query Parameters:**
- `page` (number): Halaman (default: 1)
- `limit` (number): Jumlah per halaman (default: 10)
- `status` (string): Filter berdasarkan status
- `department` (string): Filter berdasarkan department
- `date_from` (string): Filter tanggal mulai (YYYY-MM-DD)
- `date_to` (string): Filter tanggal akhir (YYYY-MM-DD)
- `search` (string): Pencarian teks

**Response:**
\`\`\`json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "ncp_number": "NCP-2024-001",
      "title": "Product Defect Report",
      "status": "submitted",
      "priority": "high",
      "department": "Production",
      "created_at": "2024-01-15T10:30:00Z",
      "created_by": {
        "id": "uuid",
        "name": "John Doe",
        "email": "john@example.com"
      }
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 25,
    "total_pages": 3
  }
}
\`\`\`

#### POST /api/reports
Membuat laporan NCP baru.

**Request Body:**
\`\`\`json
{
  "title": "Product Defect Report",
  "description": "Detailed description of the issue",
  "department": "Production",
  "priority": "high",
  "product_info": {
    "name": "Product A",
    "batch_number": "BATCH001",
    "quantity": 100
  },
  "issue_details": {
    "category": "Quality",
    "root_cause": "Material defect",
    "impact": "Customer complaint"
  },
  "attachments": ["file1.pdf", "file2.jpg"]
}
\`\`\`

**Response:**
\`\`\`json
{
  "success": true,
  "data": {
    "id": "uuid",
    "ncp_number": "NCP-2024-002",
    "title": "Product Defect Report",
    "status": "draft",
    "created_at": "2024-01-15T10:30:00Z"
  }
}
\`\`\`

#### GET /api/reports/[id]
Mendapatkan detail laporan NCP berdasarkan ID.

**Response:**
\`\`\`json
{
  "success": true,
  "data": {
    "id": "uuid",
    "ncp_number": "NCP-2024-001",
    "title": "Product Defect Report",
    "description": "Detailed description",
    "status": "qa_leader_review",
    "priority": "high",
    "department": "Production",
    "product_info": {
      "name": "Product A",
      "batch_number": "BATCH001",
      "quantity": 100
    },
    "issue_details": {
      "category": "Quality",
      "root_cause": "Material defect",
      "impact": "Customer complaint"
    },
    "attachments": [
      {
        "id": "uuid",
        "filename": "defect_photo.jpg",
        "url": "https://storage.url/file.jpg",
        "size": 1024000
      }
    ],
    "approvals": [
      {
        "id": "uuid",
        "level": "qa_leader",
        "status": "pending",
        "assigned_to": {
          "id": "uuid",
          "name": "Jane Smith",
          "email": "jane@example.com"
        },
        "assigned_at": "2024-01-15T11:00:00Z"
      }
    ],
    "audit_trail": [
      {
        "id": "uuid",
        "action": "created",
        "user": {
          "name": "John Doe",
          "email": "john@example.com"
        },
        "timestamp": "2024-01-15T10:30:00Z",
        "details": "Report created"
      }
    ],
    "created_at": "2024-01-15T10:30:00Z",
    "updated_at": "2024-01-15T11:00:00Z",
    "created_by": {
      "id": "uuid",
      "name": "John Doe",
      "email": "john@example.com"
    }
  }
}
\`\`\`

#### PUT /api/reports/[id]
Update laporan NCP (hanya untuk status draft).

**Request Body:** (sama dengan POST /api/reports)

**Response:**
\`\`\`json
{
  "success": true,
  "data": {
    "id": "uuid",
    "ncp_number": "NCP-2024-001",
    "title": "Updated Product Defect Report",
    "updated_at": "2024-01-15T12:00:00Z"
  }
}
\`\`\`

#### DELETE /api/reports/[id]
Hapus laporan NCP (hanya untuk status draft).

**Response:**
\`\`\`json
{
  "success": true,
  "message": "Report deleted successfully"
}
\`\`\`

### Approvals

#### GET /api/approvals
Mendapatkan daftar approval yang pending untuk user saat ini.

**Query Parameters:**
- `status` (string): pending, approved, rejected
- `level` (string): qa_leader, team_leader, process_lead, qa_manager

**Response:**
\`\`\`json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "report": {
        "id": "uuid",
        "ncp_number": "NCP-2024-001",
        "title": "Product Defect Report",
        "priority": "high",
        "created_at": "2024-01-15T10:30:00Z"
      },
      "level": "qa_leader",
      "status": "pending",
      "assigned_at": "2024-01-15T11:00:00Z",
      "due_date": "2024-01-17T11:00:00Z"
    }
  ]
}
\`\`\`

#### POST /api/approvals/[id]/approve
Approve laporan NCP.

**Request Body:**
\`\`\`json
{
  "comments": "Approved with recommendations",
  "next_approver_id": "uuid", // optional, untuk assign approver berikutnya
  "recommendations": "Implement additional quality checks"
}
\`\`\`

**Response:**
\`\`\`json
{
  "success": true,
  "data": {
    "id": "uuid",
    "status": "approved",
    "approved_at": "2024-01-15T14:00:00Z",
    "next_level": "team_leader"
  }
}
\`\`\`

#### POST /api/approvals/[id]/reject
Reject laporan NCP.

**Request Body:**
\`\`\`json
{
  "comments": "Insufficient information provided",
  "reason": "Missing critical details about root cause analysis"
}
\`\`\`

**Response:**
\`\`\`json
{
  "success": true,
  "data": {
    "id": "uuid",
    "status": "rejected",
    "rejected_at": "2024-01-15T14:00:00Z",
    "reason": "Missing critical details"
  }
}
\`\`\`

### Analytics

#### GET /api/analytics/dashboard
Mendapatkan metrics untuk dashboard.

**Response:**
\`\`\`json
{
  "success": true,
  "data": {
    "summary": {
      "total_reports": 150,
      "pending_approvals": 25,
      "approved_this_month": 45,
      "rejected_this_month": 5
    },
    "trends": {
      "monthly_reports": [
        { "month": "2024-01", "count": 20 },
        { "month": "2024-02", "count": 35 },
        { "month": "2024-03", "count": 45 }
      ],
      "approval_rates": [
        { "level": "qa_leader", "rate": 85 },
        { "level": "team_leader", "rate": 90 },
        { "level": "process_lead", "rate": 88 },
        { "level": "qa_manager", "rate": 92 }
      ]
    },
    "department_breakdown": [
      { "department": "Production", "count": 60 },
      { "department": "Quality", "count": 40 },
      { "department": "Engineering", "count": 30 }
    ]
  }
}
\`\`\`

### Users (Superadmin only)

#### GET /api/users
Mendapatkan daftar semua users.

**Response:**
\`\`\`json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "email": "user@example.com",
      "name": "John Doe",
      "role": "qa_inspector",
      "department": "Production",
      "is_active": true,
      "created_at": "2024-01-01T00:00:00Z",
      "last_login": "2024-01-15T09:00:00Z"
    }
  ]
}
\`\`\`

#### POST /api/users
Membuat user baru.

**Request Body:**
\`\`\`json
{
  "email": "newuser@example.com",
  "name": "New User",
  "role": "qa_inspector",
  "department": "Production",
  "password": "temporaryPassword123"
}
\`\`\`

#### PUT /api/users/[id]
Update user information.

**Request Body:**
\`\`\`json
{
  "name": "Updated Name",
  "role": "qa_leader",
  "department": "Quality",
  "is_active": false
}
\`\`\`

## Error Handling

### Error Response Format
\`\`\`json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": {
      "field": "email",
      "message": "Email is required"
    }
  }
}
\`\`\`

### Common Error Codes
- `AUTHENTICATION_ERROR` (401): Invalid or missing authentication
- `AUTHORIZATION_ERROR` (403): Insufficient permissions
- `VALIDATION_ERROR` (400): Invalid input data
- `NOT_FOUND` (404): Resource not found
- `CONFLICT` (409): Resource conflict (e.g., duplicate email)
- `INTERNAL_ERROR` (500): Server error

## Rate Limiting

- **General API**: 100 requests per minute per user
- **Authentication**: 10 requests per minute per IP
- **File Upload**: 5 requests per minute per user

## File Upload

### POST /api/upload
Upload file attachment.

**Request:** Multipart form data
- `file`: File to upload (max 10MB)
- `report_id`: Associated report ID (optional)

**Response:**
\`\`\`json
{
  "success": true,
  "data": {
    "id": "uuid",
    "filename": "document.pdf",
    "url": "https://storage.url/file.pdf",
    "size": 1024000,
    "mime_type": "application/pdf"
  }
}
\`\`\`

## Webhooks

### Approval Notifications
Sistem akan mengirim webhook notifications untuk approval events.

**Endpoint:** `POST /api/webhooks/approval`

**Payload:**
\`\`\`json
{
  "event": "approval.pending",
  "data": {
    "report_id": "uuid",
    "ncp_number": "NCP-2024-001",
    "approver": {
      "id": "uuid",
      "email": "approver@example.com"
    },
    "level": "qa_leader",
    "due_date": "2024-01-17T11:00:00Z"
  }
}
