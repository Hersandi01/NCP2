import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { CheckCircle, Clock, Eye } from "lucide-react"

const statusColors = {
  qa_leader_review: "bg-yellow-500",
  team_leader_review: "bg-orange-500",
  process_lead_review: "bg-purple-500",
  qa_manager_review: "bg-indigo-500",
}

const priorityColors = {
  low: "bg-green-500",
  medium: "bg-yellow-500",
  high: "bg-orange-500",
  critical: "bg-red-500",
}

export default async function ApprovalsPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/auth/login")
  }

  // Only certain roles can access approvals
  if (!["qa_leader", "team_leader", "process_lead", "qa_manager", "superadmin"].includes(profile.role)) {
    redirect("/dashboard")
  }

  // Get pending approvals based on user role
  let pendingQuery = supabase
    .from("ncp_reports")
    .select(`
      *,
      reporter:profiles!ncp_reports_reporter_id_fkey(full_name),
      department:departments(name)
    `)
    .order("created_at", { ascending: false })

  // Filter based on role and approval stage
  if (profile.role === "qa_leader") {
    pendingQuery = pendingQuery.eq("status", "qa_leader_review")
  } else if (profile.role === "team_leader") {
    pendingQuery = pendingQuery.eq("status", "team_leader_review")
  } else if (profile.role === "process_lead") {
    pendingQuery = pendingQuery.eq("status", "process_lead_review")
  } else if (profile.role === "qa_manager") {
    pendingQuery = pendingQuery.eq("status", "qa_manager_review")
  }

  const { data: pendingReports } = await pendingQuery

  // Get completed approvals (reports user has already approved)
  let completedQuery = supabase
    .from("ncp_reports")
    .select(`
      *,
      reporter:profiles!ncp_reports_reporter_id_fkey(full_name),
      department:departments(name)
    `)
    .order("updated_at", { ascending: false })

  if (profile.role === "qa_leader") {
    completedQuery = completedQuery.not("qa_leader_approved_at", "is", null)
  } else if (profile.role === "team_leader") {
    completedQuery = completedQuery.not("team_leader_approved_at", "is", null)
  } else if (profile.role === "process_lead") {
    completedQuery = completedQuery.not("process_lead_approved_at", "is", null)
  } else if (profile.role === "qa_manager") {
    completedQuery = completedQuery.not("qa_manager_approved_at", "is", null)
  }

  const { data: completedReports } = await completedQuery

  return (
    <div className="flex h-screen bg-background">
      <Sidebar userRole={profile.role} userName={profile.full_name} />

      <main className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-3xl font-bold text-foreground">Approvals</h1>
            <p className="text-muted-foreground">Review and approve NCP reports assigned to you</p>
          </div>

          {/* Tabs for Pending and Completed */}
          <Tabs defaultValue="pending" className="space-y-6">
            <TabsList className="bg-muted">
              <TabsTrigger value="pending" className="data-[state=active]:bg-background">
                Pending Approval ({pendingReports?.length || 0})
              </TabsTrigger>
              <TabsTrigger value="completed" className="data-[state=active]:bg-background">
                Completed ({completedReports?.length || 0})
              </TabsTrigger>
            </TabsList>

            {/* Pending Approvals */}
            <TabsContent value="pending" className="space-y-4">
              {pendingReports && pendingReports.length > 0 ? (
                pendingReports.map((report: any) => (
                  <Card key={report.id} className="bg-card border-border">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="text-lg font-semibold text-card-foreground">{report.ncp_number}</h3>
                            <Badge className={`${statusColors[report.status as keyof typeof statusColors]} text-white`}>
                              PENDING REVIEW
                            </Badge>
                            <Badge
                              className={`${priorityColors[report.priority as keyof typeof priorityColors]} text-white`}
                            >
                              {report.priority.toUpperCase()}
                            </Badge>
                          </div>
                          <p className="text-card-foreground font-medium mb-1">{report.title}</p>
                          <p className="text-muted-foreground text-sm mb-3 line-clamp-2">{report.description}</p>
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                            <span>Reporter: {report.reporter?.full_name}</span>
                            <span>•</span>
                            <span>Category: {report.category.replace("_", " ")}</span>
                            <span>•</span>
                            <span>
                              Submitted: {new Date(report.submitted_at || report.created_at).toLocaleDateString()}
                            </span>
                            {report.department && (
                              <>
                                <span>•</span>
                                <span>Dept: {report.department.name}</span>
                              </>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Link href={`/reports/${report.id}`}>
                            <Button
                              variant="outline"
                              size="sm"
                              className="border-border text-foreground hover:bg-accent bg-transparent"
                            >
                              <Eye className="h-4 w-4 mr-2" />
                              Review
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card className="bg-card border-border">
                  <CardContent className="p-12 text-center">
                    <CheckCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-card-foreground mb-2">No pending approvals</h3>
                    <p className="text-muted-foreground">
                      All reports have been reviewed. New reports will appear here when they need your approval.
                    </p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Completed Approvals */}
            <TabsContent value="completed" className="space-y-4">
              {completedReports && completedReports.length > 0 ? (
                completedReports.map((report: any) => (
                  <Card key={report.id} className="bg-card border-border">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="text-lg font-semibold text-card-foreground">{report.ncp_number}</h3>
                            <Badge className="bg-green-500 text-white">APPROVED</Badge>
                            <Badge
                              className={`${priorityColors[report.priority as keyof typeof priorityColors]} text-white`}
                            >
                              {report.priority.toUpperCase()}
                            </Badge>
                          </div>
                          <p className="text-card-foreground font-medium mb-1">{report.title}</p>
                          <p className="text-muted-foreground text-sm mb-3 line-clamp-2">{report.description}</p>
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                            <span>Reporter: {report.reporter?.full_name}</span>
                            <span>•</span>
                            <span>
                              Approved:{" "}
                              {new Date(
                                report[`${profile.role}_approved_at`] || report.updated_at,
                              ).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Link href={`/reports/${report.id}`}>
                            <Button
                              variant="outline"
                              size="sm"
                              className="border-border text-foreground hover:bg-accent bg-transparent"
                            >
                              <Eye className="h-4 w-4 mr-2" />
                              View
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card className="bg-card border-border">
                  <CardContent className="p-12 text-center">
                    <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-card-foreground mb-2">No completed approvals</h3>
                    <p className="text-muted-foreground">Reports you have approved will appear here.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
