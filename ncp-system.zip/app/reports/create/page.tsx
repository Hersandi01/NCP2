import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Sidebar } from "@/components/dashboard/sidebar"
import { NCPReportForm } from "@/components/reports/ncp-report-form"

export default async function CreateReportPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/auth/login")
  }

  // Only QA Inspectors and Superadmins can create reports
  if (profile.role !== "qa_inspector" && profile.role !== "superadmin") {
    redirect("/dashboard")
  }

  // Get departments for dropdown
  const { data: departments } = await supabase.from("departments").select("*").eq("is_active", true).order("name")

  return (
    <div className="flex h-screen bg-background">
      <Sidebar userRole={profile.role} userName={profile.full_name} />

      <main className="flex-1 overflow-auto">
        <div className="p-6">
          <div className="max-w-4xl mx-auto">
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-foreground">Create NCP Report</h1>
              <p className="text-muted-foreground">Report a new non-conformance product issue</p>
            </div>

            <NCPReportForm departments={departments || []} userId={user.id} mode="create" />
          </div>
        </div>
      </main>
    </div>
  )
}
