import { redirect, notFound } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Sidebar } from "@/components/dashboard/sidebar"
import { ApprovalForm } from "@/components/approvals/approval-form"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import Link from "next/link"
import {
  ArrowLeft,
  Edit,
  FileText,
  Calendar,
  MapPin,
  Package,
  Hash,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
} from "lucide-react"

const statusColors = {
  draft: "bg-gray-500",
  submitted: "bg-blue-500",
  qa_leader_review: "bg-yellow-500",
  team_leader_review: "bg-orange-500",
  process_lead_review: "bg-purple-500",
  qa_manager_review: "bg-indigo-500",
  approved: "bg-green-500",
  rejected: "bg-red-500",
  closed: "bg-gray-400",
}

const priorityColors = {
  low: "bg-green-500",
  medium: "bg-yellow-500",
  high: "bg-orange-500",
  critical: "bg-red-500",
}

export default async function ReportDetailPage({ params }: { params: { id: string } }) {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/auth/login")
  }

  // Get report details
  const { data: report } = await supabase
    .from("ncp_reports")
    .select(`
      *,
      reporter:profiles!ncp_reports_reporter_id_fkey(full_name, email),
      department:departments(name),
      qa_leader:profiles!ncp_reports_qa_leader_id_fkey(full_name),
      team_leader:profiles!ncp_reports_team_leader_id_fkey(full_name),
      process_lead:profiles!ncp_reports_process_lead_id_fkey(full_name),
      qa_manager:profiles!ncp_reports_qa_manager_id_fkey(full_name)
    `)
    .eq("id", params.id)
    .single()

  if (!report) {
    notFound()
  }

  // Check if user has access to this report
  const hasAccess =
    report.reporter_id === user.id ||
    report.qa_leader_id === user.id ||
    report.team_leader_id === user.id ||
    report.process_lead_id === user.id ||
    report.qa_manager_id === user.id ||
    profile.role === "superadmin"

  if (!hasAccess) {
    redirect("/dashboard")
  }

  // Get attachments
  const { data: attachments } = await supabase.from("ncp_attachments").select("*").eq("ncp_report_id", report.id)

  // Check if current user can approve this report
  const canApprove = report.status === `${profile.role}_review`

  return (
    <div className="flex h-screen bg-background">
      <Sidebar userRole={profile.role} userName={profile.full_name} />

      <main className="flex-1 overflow-auto">
        <div className="p-6">
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Link href="/reports">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-border text-foreground hover:bg-accent bg-transparent"
                  >
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Back to Reports
                  </Button>
                </Link>
                <div>
                  <h1 className="text-3xl font-bold text-foreground">{report.ncp_number}</h1>
                  <p className="text-muted-foreground">{report.title}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Badge className={`${statusColors[report.status as keyof typeof statusColors]} text-white`}>
                  {report.status.replace("_", " ").toUpperCase()}
                </Badge>
                <Badge className={`${priorityColors[report.priority as keyof typeof priorityColors]} text-white`}>
                  {report.priority.toUpperCase()}
                </Badge>
                {report.status === "draft" && report.reporter_id === user.id && (
                  <Link href={`/reports/${report.id}/edit`}>
                    <Button size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                      <Edit className="h-4 w-4 mr-2" />
                      Edit
                    </Button>
                  </Link>
                )}
              </div>
            </div>

            {/* Approval Form - Show if user can approve */}
            {canApprove && <ApprovalForm report={report} userRole={profile.role} userId={user.id} />}

            {/* Basic Information */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Report Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium text-card-foreground">Category:</span>
                      <span className="text-sm text-muted-foreground capitalize">
                        {report.category.replace("_", " ")}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium text-card-foreground">Created:</span>
                      <span className="text-sm text-muted-foreground">
                        {new Date(report.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-medium text-card-foreground">Reporter:</span>
                      <span className="text-sm text-muted-foreground">{report.reporter?.full_name}</span>
                    </div>
                  </div>
                  <div className="space-y-3">
                    {report.department && (
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium text-card-foreground">Department:</span>
                        <span className="text-sm text-muted-foreground">{report.department.name}</span>
                      </div>
                    )}
                    {report.date_discovered && (
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium text-card-foreground">Date Discovered:</span>
                        <span className="text-sm text-muted-foreground">
                          {new Date(report.date_discovered).toLocaleDateString()}
                        </span>
                      </div>
                    )}
                    {report.location && (
                      <div className="flex items-center space-x-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium text-card-foreground">Location:</span>
                        <span className="text-sm text-muted-foreground">{report.location}</span>
                      </div>
                    )}
                  </div>
                </div>

                <Separator className="bg-border" />

                <div>
                  <h4 className="text-sm font-medium text-card-foreground mb-2">Description</h4>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">{report.description}</p>
                </div>
              </CardContent>
            </Card>

            {/* Product Details */}
            {(report.product_name || report.batch_number || report.quantity_affected) && (
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-card-foreground">Product/Process Details</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-3">
                    {report.product_name && (
                      <div className="flex items-center space-x-2">
                        <Package className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium text-card-foreground">Product:</span>
                        <span className="text-sm text-muted-foreground">{report.product_name}</span>
                      </div>
                    )}
                    {report.batch_number && (
                      <div className="flex items-center space-x-2">
                        <Hash className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium text-card-foreground">Batch:</span>
                        <span className="text-sm text-muted-foreground">{report.batch_number}</span>
                      </div>
                    )}
                    {report.quantity_affected && (
                      <div className="flex items-center space-x-2">
                        <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium text-card-foreground">Quantity:</span>
                        <span className="text-sm text-muted-foreground">{report.quantity_affected} units</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Root Cause Analysis */}
            {(report.root_cause || report.immediate_action || report.corrective_action || report.preventive_action) && (
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-card-foreground">Root Cause Analysis & Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {report.root_cause && (
                    <div>
                      <h4 className="text-sm font-medium text-card-foreground mb-2">Root Cause</h4>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap">{report.root_cause}</p>
                    </div>
                  )}
                  {report.immediate_action && (
                    <div>
                      <h4 className="text-sm font-medium text-card-foreground mb-2">Immediate Action</h4>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap">{report.immediate_action}</p>
                    </div>
                  )}
                  {report.corrective_action && (
                    <div>
                      <h4 className="text-sm font-medium text-card-foreground mb-2">Corrective Action</h4>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap">{report.corrective_action}</p>
                    </div>
                  )}
                  {report.preventive_action && (
                    <div>
                      <h4 className="text-sm font-medium text-card-foreground mb-2">Preventive Action</h4>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap">{report.preventive_action}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Attachments */}
            {attachments && attachments.length > 0 && (
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-card-foreground">Attachments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {attachments.map((attachment) => (
                      <div key={attachment.id} className="flex items-center justify-between p-3 bg-muted rounded-md">
                        <div className="flex items-center space-x-3">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm text-card-foreground">{attachment.file_name}</span>
                          {attachment.file_size && (
                            <span className="text-xs text-muted-foreground">
                              ({Math.round(attachment.file_size / 1024)} KB)
                            </span>
                          )}
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-border text-foreground hover:bg-accent bg-transparent"
                        >
                          Download
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Approval Workflow */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Approval Workflow</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Submitted */}
                  <div className="flex items-center space-x-4">
                    <div
                      className={`w-3 h-3 rounded-full ${report.status !== "draft" ? "bg-green-500" : "bg-gray-400"}`}
                    ></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-card-foreground">Submitted</p>
                      {report.submitted_at && (
                        <p className="text-xs text-muted-foreground">
                          {new Date(report.submitted_at).toLocaleString()}
                        </p>
                      )}
                    </div>
                    {report.status !== "draft" && <CheckCircle className="h-4 w-4 text-green-500" />}
                  </div>

                  {/* QA Leader Review */}
                  <div className="flex items-center space-x-4">
                    <div
                      className={`w-3 h-3 rounded-full ${
                        report.qa_leader_approved_at
                          ? "bg-green-500"
                          : report.status === "qa_leader_review"
                            ? "bg-yellow-500"
                            : "bg-gray-400"
                      }`}
                    ></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-card-foreground">QA Leader Review</p>
                      {report.qa_leader && (
                        <p className="text-xs text-muted-foreground">Assigned to: {report.qa_leader.full_name}</p>
                      )}
                      {report.qa_leader_approved_at && (
                        <p className="text-xs text-muted-foreground">
                          Approved: {new Date(report.qa_leader_approved_at).toLocaleString()}
                        </p>
                      )}
                      {report.qa_leader_comments && (
                        <p className="text-xs text-muted-foreground mt-1 italic">"{report.qa_leader_comments}"</p>
                      )}
                    </div>
                    {report.qa_leader_approved_at && <CheckCircle className="h-4 w-4 text-green-500" />}
                    {report.status === "qa_leader_review" && <Clock className="h-4 w-4 text-yellow-500" />}
                  </div>

                  {/* Team Leader Review */}
                  <div className="flex items-center space-x-4">
                    <div
                      className={`w-3 h-3 rounded-full ${
                        report.team_leader_approved_at
                          ? "bg-green-500"
                          : report.status === "team_leader_review"
                            ? "bg-orange-500"
                            : "bg-gray-400"
                      }`}
                    ></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-card-foreground">Team Leader Review</p>
                      {report.team_leader && (
                        <p className="text-xs text-muted-foreground">Assigned to: {report.team_leader.full_name}</p>
                      )}
                      {report.team_leader_approved_at && (
                        <p className="text-xs text-muted-foreground">
                          Approved: {new Date(report.team_leader_approved_at).toLocaleString()}
                        </p>
                      )}
                      {report.team_leader_comments && (
                        <p className="text-xs text-muted-foreground mt-1 italic">"{report.team_leader_comments}"</p>
                      )}
                    </div>
                    {report.team_leader_approved_at && <CheckCircle className="h-4 w-4 text-green-500" />}
                    {report.status === "team_leader_review" && <Clock className="h-4 w-4 text-orange-500" />}
                  </div>

                  {/* Process Lead Review */}
                  <div className="flex items-center space-x-4">
                    <div
                      className={`w-3 h-3 rounded-full ${
                        report.process_lead_approved_at
                          ? "bg-green-500"
                          : report.status === "process_lead_review"
                            ? "bg-purple-500"
                            : "bg-gray-400"
                      }`}
                    ></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-card-foreground">Process Lead Review</p>
                      {report.process_lead && (
                        <p className="text-xs text-muted-foreground">Assigned to: {report.process_lead.full_name}</p>
                      )}
                      {report.process_lead_approved_at && (
                        <p className="text-xs text-muted-foreground">
                          Approved: {new Date(report.process_lead_approved_at).toLocaleString()}
                        </p>
                      )}
                      {report.process_lead_comments && (
                        <p className="text-xs text-muted-foreground mt-1 italic">"{report.process_lead_comments}"</p>
                      )}
                    </div>
                    {report.process_lead_approved_at && <CheckCircle className="h-4 w-4 text-green-500" />}
                    {report.status === "process_lead_review" && <Clock className="h-4 w-4 text-purple-500" />}
                  </div>

                  {/* QA Manager Review */}
                  <div className="flex items-center space-x-4">
                    <div
                      className={`w-3 h-3 rounded-full ${
                        report.qa_manager_approved_at
                          ? "bg-green-500"
                          : report.status === "qa_manager_review"
                            ? "bg-indigo-500"
                            : "bg-gray-400"
                      }`}
                    ></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-card-foreground">QA Manager Final Review</p>
                      {report.qa_manager && (
                        <p className="text-xs text-muted-foreground">Assigned to: {report.qa_manager.full_name}</p>
                      )}
                      {report.qa_manager_approved_at && (
                        <p className="text-xs text-muted-foreground">
                          Approved: {new Date(report.qa_manager_approved_at).toLocaleString()}
                        </p>
                      )}
                      {report.qa_manager_comments && (
                        <p className="text-xs text-muted-foreground mt-1 italic">"{report.qa_manager_comments}"</p>
                      )}
                    </div>
                    {report.qa_manager_approved_at && <CheckCircle className="h-4 w-4 text-green-500" />}
                    {report.status === "qa_manager_review" && <Clock className="h-4 w-4 text-indigo-500" />}
                  </div>

                  {/* Final Status */}
                  {(report.status === "approved" || report.status === "rejected") && (
                    <div className="flex items-center space-x-4 pt-2 border-t border-border">
                      <div
                        className={`w-3 h-3 rounded-full ${
                          report.status === "approved" ? "bg-green-500" : "bg-red-500"
                        }`}
                      ></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-card-foreground">
                          {report.status === "approved" ? "Approved" : "Rejected"}
                        </p>
                        {report.closed_at && (
                          <p className="text-xs text-muted-foreground">{new Date(report.closed_at).toLocaleString()}</p>
                        )}
                      </div>
                      {report.status === "approved" ? (
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500" />
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
