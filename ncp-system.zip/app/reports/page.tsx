import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ExportButton } from "@/components/reports/export-button"
import Link from "next/link"
import { Plus, Search, FileText } from "lucide-react"

const statusColors = {
  draft: "bg-gray-500",
  submitted: "bg-blue-500",
  qa_leader_review: "bg-yellow-500",
  team_leader_review: "bg-orange-500",
  process_lead_review: "bg-purple-500",
  qa_manager_review: "bg-indigo-500",
  approved: "bg-green-500",
  rejected: "bg-red-500",
  closed: "bg-gray-400",
}

const priorityColors = {
  low: "bg-green-500",
  medium: "bg-yellow-500",
  high: "bg-orange-500",
  critical: "bg-red-500",
}

export default async function ReportsPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/auth/login")
  }

  // Get reports based on user role
  let reportsQuery = supabase
    .from("ncp_reports")
    .select(`
      *,
      reporter:profiles!ncp_reports_reporter_id_fkey(full_name),
      department:departments(name)
    `)
    .order("created_at", { ascending: false })

  // Filter based on user role
  if (profile.role === "qa_inspector") {
    reportsQuery = reportsQuery.eq("reporter_id", user.id)
  } else if (profile.role !== "superadmin") {
    // Other roles can see reports assigned to them or reports they can approve
    reportsQuery = reportsQuery.or(
      `reporter_id.eq.${user.id},qa_leader_id.eq.${user.id},team_leader_id.eq.${user.id},process_lead_id.eq.${user.id},qa_manager_id.eq.${user.id}`,
    )
  }

  const { data: reports } = await reportsQuery

  return (
    <div className="flex h-screen bg-background">
      <Sidebar userRole={profile.role} userName={profile.full_name} />

      <main className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">NCP Reports</h1>
              <p className="text-muted-foreground">Manage and track non-conformance product reports</p>
            </div>
            <div className="flex items-center space-x-2">
              <ExportButton />
              {(profile.role === "qa_inspector" || profile.role === "superadmin") && (
                <Link href="/reports/create">
                  <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                    <Plus className="h-4 w-4 mr-2" />
                    Create Report
                  </Button>
                </Link>
              )}
            </div>
          </div>

          {/* Filters */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-card-foreground">Filters</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4">
                <div className="flex-1 min-w-[200px]">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input placeholder="Search reports..." className="pl-10 bg-input border-border text-foreground" />
                  </div>
                </div>
                <Select>
                  <SelectTrigger className="w-[180px] bg-input border-border text-foreground">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    <SelectItem value="all" className="text-popover-foreground">
                      All Status
                    </SelectItem>
                    <SelectItem value="draft" className="text-popover-foreground">
                      Draft
                    </SelectItem>
                    <SelectItem value="submitted" className="text-popover-foreground">
                      Submitted
                    </SelectItem>
                    <SelectItem value="approved" className="text-popover-foreground">
                      Approved
                    </SelectItem>
                    <SelectItem value="rejected" className="text-popover-foreground">
                      Rejected
                    </SelectItem>
                  </SelectContent>
                </Select>
                <Select>
                  <SelectTrigger className="w-[180px] bg-input border-border text-foreground">
                    <SelectValue placeholder="Priority" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    <SelectItem value="all" className="text-popover-foreground">
                      All Priority
                    </SelectItem>
                    <SelectItem value="low" className="text-popover-foreground">
                      Low
                    </SelectItem>
                    <SelectItem value="medium" className="text-popover-foreground">
                      Medium
                    </SelectItem>
                    <SelectItem value="high" className="text-popover-foreground">
                      High
                    </SelectItem>
                    <SelectItem value="critical" className="text-popover-foreground">
                      Critical
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Reports List */}
          <div className="space-y-4">
            {reports && reports.length > 0 ? (
              reports.map((report: any) => (
                <Card key={report.id} className="bg-card border-border hover:bg-card/80 transition-colors">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <Link href={`/reports/${report.id}`}>
                            <h3 className="text-lg font-semibold text-card-foreground hover:text-primary cursor-pointer">
                              {report.ncp_number}
                            </h3>
                          </Link>
                          <Badge className={`${statusColors[report.status as keyof typeof statusColors]} text-white`}>
                            {report.status.replace("_", " ").toUpperCase()}
                          </Badge>
                          <Badge
                            className={`${priorityColors[report.priority as keyof typeof priorityColors]} text-white`}
                          >
                            {report.priority.toUpperCase()}
                          </Badge>
                        </div>
                        <p className="text-card-foreground font-medium mb-1">{report.title}</p>
                        <p className="text-muted-foreground text-sm mb-3 line-clamp-2">{report.description}</p>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span>Reporter: {report.reporter?.full_name}</span>
                          <span>•</span>
                          <span>Category: {report.category.replace("_", " ")}</span>
                          <span>•</span>
                          <span>Created: {new Date(report.created_at).toLocaleDateString()}</span>
                          {report.department && (
                            <>
                              <span>•</span>
                              <span>Dept: {report.department.name}</span>
                            </>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {report.status === "draft" && report.reporter_id === user.id && (
                          <Link href={`/reports/${report.id}/edit`}>
                            <Button
                              variant="outline"
                              size="sm"
                              className="border-border text-foreground hover:bg-accent bg-transparent"
                            >
                              Edit
                            </Button>
                          </Link>
                        )}
                        <Link href={`/reports/${report.id}`}>
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-border text-foreground hover:bg-accent bg-transparent"
                          >
                            View
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="bg-card border-border">
                <CardContent className="p-12 text-center">
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-card-foreground mb-2">No reports found</h3>
                  <p className="text-muted-foreground mb-4">
                    {profile.role === "qa_inspector"
                      ? "You haven't created any reports yet."
                      : "No reports are available for your review."}
                  </p>
                  {(profile.role === "qa_inspector" || profile.role === "superadmin") && (
                    <Link href="/reports/create">
                      <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                        <Plus className="h-4 w-4 mr-2" />
                        Create Your First Report
                      </Button>
                    </Link>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
