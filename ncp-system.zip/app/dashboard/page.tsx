import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Sidebar } from "@/components/dashboard/sidebar"
import { StatsCard } from "@/components/dashboard/stats-card"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, AlertTriangle, CheckCircle, Clock, TrendingUp, Users } from "lucide-react"

export default async function DashboardPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/auth/login")
  }

  // Get dashboard statistics
  const { data: totalReports } = await supabase.from("ncp_reports").select("id", { count: "exact" })

  const { data: pendingReports } = await supabase
    .from("ncp_reports")
    .select("id", { count: "exact" })
    .in("status", ["submitted", "qa_leader_review", "team_leader_review", "process_lead_review", "qa_manager_review"])

  const { data: approvedReports } = await supabase
    .from("ncp_reports")
    .select("id", { count: "exact" })
    .eq("status", "approved")

  const { data: criticalReports } = await supabase
    .from("ncp_reports")
    .select("id", { count: "exact" })
    .eq("priority", "critical")

  return (
    <div className="flex h-screen bg-background">
      <Sidebar userRole={profile.role} userName={profile.full_name} />

      <main className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
            <p className="text-muted-foreground">
              Welcome back, {profile.full_name}. Here's what's happening with your NCPs.
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <StatsCard
              title="Total Reports"
              value={totalReports?.length || 0}
              description="All NCP reports in system"
              icon={FileText}
              trend={{ value: 12, isPositive: true }}
            />
            <StatsCard
              title="Pending Approval"
              value={pendingReports?.length || 0}
              description="Awaiting review"
              icon={Clock}
              trend={{ value: -5, isPositive: false }}
            />
            <StatsCard
              title="Approved"
              value={approvedReports?.length || 0}
              description="Completed reports"
              icon={CheckCircle}
              trend={{ value: 8, isPositive: true }}
            />
            <StatsCard
              title="Critical Issues"
              value={criticalReports?.length || 0}
              description="High priority reports"
              icon={AlertTriangle}
            />
          </div>

          {/* Recent Activity */}
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Recent Reports</CardTitle>
                <CardDescription className="text-muted-foreground">Latest NCP reports submitted</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-2 h-2 bg-chart-2 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-card-foreground">Product Defect - Batch #2024001</p>
                      <p className="text-xs text-muted-foreground">2 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-2 h-2 bg-chart-4 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-card-foreground">Process Deviation - Line A</p>
                      <p className="text-xs text-muted-foreground">4 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-2 h-2 bg-chart-3 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-card-foreground">Equipment Failure - Machine B2</p>
                      <p className="text-xs text-muted-foreground">1 day ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Quick Actions</CardTitle>
                <CardDescription className="text-muted-foreground">Common tasks for your role</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {profile.role === "qa_inspector" && (
                    <>
                      <button className="w-full text-left p-3 rounded-lg bg-primary/10 hover:bg-primary/20 border border-primary/20 transition-colors">
                        <div className="flex items-center space-x-3">
                          <AlertTriangle className="h-4 w-4 text-primary" />
                          <span className="text-sm font-medium text-foreground">Create New Report</span>
                        </div>
                      </button>
                      <button className="w-full text-left p-3 rounded-lg bg-muted hover:bg-muted/80 transition-colors">
                        <div className="flex items-center space-x-3">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm font-medium text-foreground">View My Reports</span>
                        </div>
                      </button>
                    </>
                  )}
                  {(profile.role === "qa_leader" ||
                    profile.role === "team_leader" ||
                    profile.role === "process_lead" ||
                    profile.role === "qa_manager") && (
                    <>
                      <button className="w-full text-left p-3 rounded-lg bg-primary/10 hover:bg-primary/20 border border-primary/20 transition-colors">
                        <div className="flex items-center space-x-3">
                          <CheckCircle className="h-4 w-4 text-primary" />
                          <span className="text-sm font-medium text-foreground">Review Pending Reports</span>
                        </div>
                      </button>
                      <button className="w-full text-left p-3 rounded-lg bg-muted hover:bg-muted/80 transition-colors">
                        <div className="flex items-center space-x-3">
                          <TrendingUp className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm font-medium text-foreground">View Analytics</span>
                        </div>
                      </button>
                    </>
                  )}
                  {profile.role === "superadmin" && (
                    <>
                      <button className="w-full text-left p-3 rounded-lg bg-primary/10 hover:bg-primary/20 border border-primary/20 transition-colors">
                        <div className="flex items-center space-x-3">
                          <Users className="h-4 w-4 text-primary" />
                          <span className="text-sm font-medium text-foreground">Manage Users</span>
                        </div>
                      </button>
                      <button className="w-full text-left p-3 rounded-lg bg-muted hover:bg-muted/80 transition-colors">
                        <div className="flex items-center space-x-3">
                          <TrendingUp className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm font-medium text-foreground">System Analytics</span>
                        </div>
                      </button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
