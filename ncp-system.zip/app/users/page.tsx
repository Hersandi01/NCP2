import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Sidebar } from "@/components/dashboard/sidebar"
import { UserManagement } from "@/components/users/user-management"

export default async function UsersPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/auth/login")
  }

  // Only superadmin can access user management
  if (profile.role !== "superadmin") {
    redirect("/dashboard")
  }

  // Get all users
  const { data: users } = await supabase.from("profiles").select("*").order("created_at", { ascending: false })

  // Get departments
  const { data: departments } = await supabase.from("departments").select("*").eq("is_active", true).order("name")

  return (
    <div className="flex h-screen bg-background">
      <Sidebar userRole={profile.role} userName={profile.full_name} />

      <main className="flex-1 overflow-auto">
        <div className="p-6">
          <div className="max-w-6xl mx-auto">
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-foreground">User Management</h1>
              <p className="text-muted-foreground">Manage system users and their roles</p>
            </div>

            <UserManagement users={users || []} departments={departments || []} />
          </div>
        </div>
      </main>
    </div>
  )
}
