import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SystemSettings } from "@/components/settings/system-settings"
import { DepartmentSettings } from "@/components/settings/department-settings"

export default async function SettingsPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/auth/login")
  }

  // Only certain roles can access settings
  if (!["qa_manager", "superadmin"].includes(profile.role)) {
    redirect("/dashboard")
  }

  // Get departments
  const { data: departments } = await supabase.from("departments").select("*").order("name")

  return (
    <div className="flex h-screen bg-background">
      <Sidebar userRole={profile.role} userName={profile.full_name} />

      <main className="flex-1 overflow-auto">
        <div className="p-6">
          <div className="max-w-4xl mx-auto space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Settings</h1>
              <p className="text-muted-foreground">Manage system configuration and preferences</p>
            </div>

            <Tabs defaultValue="departments" className="space-y-4">
              <TabsList className="bg-muted">
                <TabsTrigger value="departments" className="data-[state=active]:bg-background">
                  Departments
                </TabsTrigger>
                {profile.role === "superadmin" && (
                  <TabsTrigger value="system" className="data-[state=active]:bg-background">
                    System
                  </TabsTrigger>
                )}
              </TabsList>

              <TabsContent value="departments">
                <DepartmentSettings departments={departments || []} />
              </TabsContent>

              {profile.role === "superadmin" && (
                <TabsContent value="system">
                  <SystemSettings />
                </TabsContent>
              )}
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  )
}
