import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Bell, CheckCircle, AlertTriangle, Info, Eye } from "lucide-react"

const notificationIcons = {
  approval_request: AlertTriangle,
  approval_success: CheckCircle,
  approval_rejected: AlertTriangle,
  info: Info,
}

const notificationColors = {
  approval_request: "text-yellow-500",
  approval_success: "text-green-500",
  approval_rejected: "text-red-500",
  info: "text-blue-500",
}

export default async function NotificationsPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/auth/login")
  }

  // Get notifications for user
  const { data: notifications } = await supabase
    .from("notifications")
    .select(`
      *,
      ncp_report:ncp_reports(ncp_number, title)
    `)
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  // Mark notifications as read
  if (notifications && notifications.length > 0) {
    await supabase.from("notifications").update({ is_read: true }).eq("user_id", user.id).eq("is_read", false)
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar userRole={profile.role} userName={profile.full_name} />

      <main className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-3xl font-bold text-foreground">Notifications</h1>
            <p className="text-muted-foreground">Stay updated with your NCP reports and approvals</p>
          </div>

          {/* Notifications List */}
          <div className="space-y-4">
            {notifications && notifications.length > 0 ? (
              notifications.map((notification: any) => {
                const Icon = notificationIcons[notification.type as keyof typeof notificationIcons] || Info
                const iconColor =
                  notificationColors[notification.type as keyof typeof notificationColors] || "text-blue-500"

                return (
                  <Card key={notification.id} className="bg-card border-border">
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-4">
                        <Icon className={`h-5 w-5 mt-0.5 ${iconColor}`} />
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <h3 className="text-sm font-medium text-card-foreground">{notification.title}</h3>
                            <span className="text-xs text-muted-foreground">
                              {new Date(notification.created_at).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">{notification.message}</p>
                          {notification.ncp_report && (
                            <div className="flex items-center justify-between">
                              <div className="text-xs text-muted-foreground">
                                Related: {notification.ncp_report.ncp_number} - {notification.ncp_report.title}
                              </div>
                              <Link href={`/reports/${notification.ncp_report_id}`}>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="border-border text-foreground hover:bg-accent bg-transparent"
                                >
                                  <Eye className="h-3 w-3 mr-1" />
                                  View
                                </Button>
                              </Link>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })
            ) : (
              <Card className="bg-card border-border">
                <CardContent className="p-12 text-center">
                  <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-card-foreground mb-2">No notifications</h3>
                  <p className="text-muted-foreground">You're all caught up! New notifications will appear here.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
