import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AnalyticsCharts } from "@/components/analytics/analytics-charts"
import { TrendingUp, BarChart3, Calendar } from "lucide-react"

export default async function AnalyticsPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/auth/login")
  }

  // Only certain roles can access analytics
  if (!["qa_leader", "team_leader", "process_lead", "qa_manager", "superadmin"].includes(profile.role)) {
    redirect("/dashboard")
  }

  // Get analytics data
  const { data: totalReports } = await supabase.from("ncp_reports").select("id", { count: "exact" })

  const { data: reportsByStatus } = await supabase
    .from("ncp_reports")
    .select("status")
    .then((result) => {
      if (result.data) {
        const statusCounts = result.data.reduce(
          (acc, report) => {
            acc[report.status] = (acc[report.status] || 0) + 1
            return acc
          },
          {} as Record<string, number>,
        )
        return { data: statusCounts }
      }
      return { data: {} }
    })

  const { data: reportsByPriority } = await supabase
    .from("ncp_reports")
    .select("priority")
    .then((result) => {
      if (result.data) {
        const priorityCounts = result.data.reduce(
          (acc, report) => {
            acc[report.priority] = (acc[report.priority] || 0) + 1
            return acc
          },
          {} as Record<string, number>,
        )
        return { data: priorityCounts }
      }
      return { data: {} }
    })

  const { data: reportsByCategory } = await supabase
    .from("ncp_reports")
    .select("category")
    .then((result) => {
      if (result.data) {
        const categoryCounts = result.data.reduce(
          (acc, report) => {
            acc[report.category] = (acc[report.category] || 0) + 1
            return acc
          },
          {} as Record<string, number>,
        )
        return { data: categoryCounts }
      }
      return { data: {} }
    })

  // Get monthly trends (last 12 months)
  const { data: monthlyTrends } = await supabase
    .from("ncp_reports")
    .select("created_at")
    .gte("created_at", new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString())
    .then((result) => {
      if (result.data) {
        const monthCounts = result.data.reduce(
          (acc, report) => {
            const month = new Date(report.created_at).toLocaleDateString("en-US", {
              year: "numeric",
              month: "short",
            })
            acc[month] = (acc[month] || 0) + 1
            return acc
          },
          {} as Record<string, number>,
        )
        return { data: monthCounts }
      }
      return { data: {} }
    })

  // Calculate metrics
  const approvedReports = Object.entries(reportsByStatus.data).find(([status]) => status === "approved")?.[1] || 0
  const rejectedReports = Object.entries(reportsByStatus.data).find(([status]) => status === "rejected")?.[1] || 0
  const pendingReports =
    (totalReports?.length || 0) - approvedReports - rejectedReports - (reportsByStatus.data.draft || 0)

  const approvalRate = totalReports?.length ? ((approvedReports / totalReports.length) * 100).toFixed(1) : "0"
  const rejectionRate = totalReports?.length ? ((rejectedReports / totalReports.length) * 100).toFixed(1) : "0"

  return (
    <div className="flex h-screen bg-background">
      <Sidebar userRole={profile.role} userName={profile.full_name} />

      <main className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Analytics</h1>
              <p className="text-muted-foreground">Insights and trends for NCP reports</p>
            </div>
            <div className="flex items-center space-x-2">
              <Select defaultValue="12months">
                <SelectTrigger className="w-[180px] bg-input border-border text-foreground">
                  <SelectValue placeholder="Time period" />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  <SelectItem value="1month" className="text-popover-foreground">
                    Last Month
                  </SelectItem>
                  <SelectItem value="3months" className="text-popover-foreground">
                    Last 3 Months
                  </SelectItem>
                  <SelectItem value="6months" className="text-popover-foreground">
                    Last 6 Months
                  </SelectItem>
                  <SelectItem value="12months" className="text-popover-foreground">
                    Last 12 Months
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Key Metrics */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-card-foreground">Total Reports</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-card-foreground">{totalReports?.length || 0}</div>
                <p className="text-xs text-muted-foreground">All time</p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-card-foreground">Approval Rate</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-card-foreground">{approvalRate}%</div>
                <p className="text-xs text-muted-foreground">{approvedReports} approved</p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-card-foreground">Rejection Rate</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-card-foreground">{rejectionRate}%</div>
                <p className="text-xs text-muted-foreground">{rejectedReports} rejected</p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-card-foreground">Pending Review</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-card-foreground">{pendingReports}</div>
                <p className="text-xs text-muted-foreground">Awaiting approval</p>
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          <Tabs defaultValue="trends" className="space-y-4">
            <TabsList className="bg-muted">
              <TabsTrigger value="trends" className="data-[state=active]:bg-background">
                Trends
              </TabsTrigger>
              <TabsTrigger value="status" className="data-[state=active]:bg-background">
                By Status
              </TabsTrigger>
              <TabsTrigger value="category" className="data-[state=active]:bg-background">
                By Category
              </TabsTrigger>
              <TabsTrigger value="priority" className="data-[state=active]:bg-background">
                By Priority
              </TabsTrigger>
            </TabsList>

            <TabsContent value="trends">
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-card-foreground">Monthly Trends</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Number of reports created over time
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <AnalyticsCharts
                    type="line"
                    data={Object.entries(monthlyTrends.data).map(([month, count]) => ({
                      name: month,
                      value: count,
                    }))}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="status">
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-card-foreground">Reports by Status</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Distribution of reports across different statuses
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <AnalyticsCharts
                    type="pie"
                    data={Object.entries(reportsByStatus.data).map(([status, count]) => ({
                      name: status.replace("_", " ").toUpperCase(),
                      value: count,
                    }))}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="category">
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-card-foreground">Reports by Category</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Types of non-conformances reported
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <AnalyticsCharts
                    type="bar"
                    data={Object.entries(reportsByCategory.data).map(([category, count]) => ({
                      name: category.replace("_", " ").toUpperCase(),
                      value: count,
                    }))}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="priority">
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-card-foreground">Reports by Priority</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Priority distribution of reported issues
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <AnalyticsCharts
                    type="doughnut"
                    data={Object.entries(reportsByPriority.data).map(([priority, count]) => ({
                      name: priority.toUpperCase(),
                      value: count,
                    }))}
                  />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
