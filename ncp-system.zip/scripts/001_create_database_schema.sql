-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create enum types for system
CREATE TYPE user_role AS ENUM (
  'superadmin',
  'qa_inspector', 
  'qa_leader',
  'team_leader',
  'process_lead',
  'qa_manager'
);

CREATE TYPE ncp_status AS ENUM (
  'draft',
  'submitted',
  'qa_leader_review',
  'team_leader_review', 
  'process_lead_review',
  'qa_manager_review',
  'approved',
  'rejected',
  'closed'
);

CREATE TYPE ncp_priority AS ENUM (
  'low',
  'medium',
  'high',
  'critical'
);

CREATE TYPE ncp_category AS ENUM (
  'product_defect',
  'process_deviation',
  'documentation_error',
  'equipment_failure',
  'material_issue',
  'other'
);

-- Create profiles table that extends auth.users
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'qa_inspector',
  department TEXT,
  phone TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create departments table
CREATE TABLE IF NOT EXISTS public.departments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  head_id UUID REFERENCES public.profiles(id),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create NCP reports table
CREATE TABLE IF NOT EXISTS public.ncp_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ncp_number TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  category ncp_category NOT NULL,
  priority ncp_priority NOT NULL DEFAULT 'medium',
  status ncp_status NOT NULL DEFAULT 'draft',
  
  -- Reporter information
  reporter_id UUID NOT NULL REFERENCES public.profiles(id),
  department_id UUID REFERENCES public.departments(id),
  
  -- Product/Process details
  product_name TEXT,
  batch_number TEXT,
  quantity_affected INTEGER,
  date_discovered TIMESTAMP WITH TIME ZONE,
  location TEXT,
  
  -- Root cause analysis
  root_cause TEXT,
  immediate_action TEXT,
  corrective_action TEXT,
  preventive_action TEXT,
  
  -- Approval workflow
  qa_leader_id UUID REFERENCES public.profiles(id),
  qa_leader_approved_at TIMESTAMP WITH TIME ZONE,
  qa_leader_comments TEXT,
  
  team_leader_id UUID REFERENCES public.profiles(id),
  team_leader_approved_at TIMESTAMP WITH TIME ZONE,
  team_leader_comments TEXT,
  
  process_lead_id UUID REFERENCES public.profiles(id),
  process_lead_approved_at TIMESTAMP WITH TIME ZONE,
  process_lead_comments TEXT,
  
  qa_manager_id UUID REFERENCES public.profiles(id),
  qa_manager_approved_at TIMESTAMP WITH TIME ZONE,
  qa_manager_comments TEXT,
  
  -- Timestamps
  submitted_at TIMESTAMP WITH TIME ZONE,
  closed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create attachments table for file uploads
CREATE TABLE IF NOT EXISTS public.ncp_attachments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ncp_report_id UUID NOT NULL REFERENCES public.ncp_reports(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size INTEGER,
  mime_type TEXT,
  uploaded_by UUID NOT NULL REFERENCES public.profiles(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create audit trail table
CREATE TABLE IF NOT EXISTS public.ncp_audit_trail (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ncp_report_id UUID NOT NULL REFERENCES public.ncp_reports(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id),
  action TEXT NOT NULL,
  old_values JSONB,
  new_values JSONB,
  comments TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create notifications table
CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  ncp_report_id UUID REFERENCES public.ncp_reports(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'info',
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ncp_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ncp_attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ncp_audit_trail ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for profiles
CREATE POLICY "Users can view all profiles" ON public.profiles
  FOR SELECT USING (true);

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

-- Create RLS policies for departments
CREATE POLICY "Users can view all departments" ON public.departments
  FOR SELECT USING (true);

CREATE POLICY "Only superadmin can manage departments" ON public.departments
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'superadmin'
    )
  );

-- Create RLS policies for NCP reports
CREATE POLICY "Users can view NCP reports" ON public.ncp_reports
  FOR SELECT USING (
    -- Users can see reports they created
    reporter_id = auth.uid() OR
    -- Or reports assigned to them for approval
    qa_leader_id = auth.uid() OR
    team_leader_id = auth.uid() OR
    process_lead_id = auth.uid() OR
    qa_manager_id = auth.uid() OR
    -- Or if they are superadmin
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'superadmin'
    )
  );

CREATE POLICY "Users can create NCP reports" ON public.ncp_reports
  FOR INSERT WITH CHECK (reporter_id = auth.uid());

CREATE POLICY "Users can update NCP reports" ON public.ncp_reports
  FOR UPDATE USING (
    -- Reporter can update draft reports
    (reporter_id = auth.uid() AND status = 'draft') OR
    -- Approvers can update reports assigned to them
    (qa_leader_id = auth.uid() AND status = 'qa_leader_review') OR
    (team_leader_id = auth.uid() AND status = 'team_leader_review') OR
    (process_lead_id = auth.uid() AND status = 'process_lead_review') OR
    (qa_manager_id = auth.uid() AND status = 'qa_manager_review') OR
    -- Superadmin can update any report
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'superadmin'
    )
  );

-- Create RLS policies for attachments
CREATE POLICY "Users can view attachments for accessible reports" ON public.ncp_attachments
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.ncp_reports 
      WHERE id = ncp_report_id AND (
        reporter_id = auth.uid() OR
        qa_leader_id = auth.uid() OR
        team_leader_id = auth.uid() OR
        process_lead_id = auth.uid() OR
        qa_manager_id = auth.uid() OR
        EXISTS (
          SELECT 1 FROM public.profiles 
          WHERE id = auth.uid() AND role = 'superadmin'
        )
      )
    )
  );

CREATE POLICY "Users can upload attachments to their reports" ON public.ncp_attachments
  FOR INSERT WITH CHECK (
    uploaded_by = auth.uid() AND
    EXISTS (
      SELECT 1 FROM public.ncp_reports 
      WHERE id = ncp_report_id AND reporter_id = auth.uid()
    )
  );

-- Create RLS policies for audit trail
CREATE POLICY "Users can view audit trail for accessible reports" ON public.ncp_audit_trail
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.ncp_reports 
      WHERE id = ncp_report_id AND (
        reporter_id = auth.uid() OR
        qa_leader_id = auth.uid() OR
        team_leader_id = auth.uid() OR
        process_lead_id = auth.uid() OR
        qa_manager_id = auth.uid() OR
        EXISTS (
          SELECT 1 FROM public.profiles 
          WHERE id = auth.uid() AND role = 'superadmin'
        )
      )
    )
  );

CREATE POLICY "System can insert audit trail" ON public.ncp_audit_trail
  FOR INSERT WITH CHECK (user_id = auth.uid());

-- Create RLS policies for notifications
CREATE POLICY "Users can view own notifications" ON public.notifications
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can update own notifications" ON public.notifications
  FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "System can create notifications" ON public.notifications
  FOR INSERT WITH CHECK (true);
