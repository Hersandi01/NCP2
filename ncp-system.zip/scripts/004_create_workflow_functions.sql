-- Function to automatically assign first approver when report is submitted
CREATE OR REPLACE FUNCTION public.assign_first_approver()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- When status changes to 'submitted', assign to QA Leader review
  IF NEW.status = 'submitted' AND OLD.status = 'draft' THEN
    NEW.status = 'qa_leader_review';
    
    -- Auto-assign to a QA Leader if not already assigned
    IF NEW.qa_leader_id IS NULL THEN
      SELECT id INTO NEW.qa_leader_id
      FROM public.profiles
      WHERE role = 'qa_leader' AND is_active = true
      ORDER BY created_at
      LIMIT 1;
    END IF;
    
    -- Create notification for QA Leader
    IF NEW.qa_leader_id IS NOT NULL THEN
      INSERT INTO public.notifications (user_id, ncp_report_id, title, message, type)
      VALUES (
        NEW.qa_leader_id,
        NEW.id,
        'New NCP Report for Review',
        'NCP ' || NEW.ncp_number || ' has been submitted and requires your review.',
        'approval_request'
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger for auto-assignment
DROP TRIGGER IF EXISTS auto_assign_approver ON public.ncp_reports;
CREATE TRIGGER auto_assign_approver
  BEFORE UPDATE ON public.ncp_reports
  FOR EACH ROW
  EXECUTE FUNCTION public.assign_first_approver();

-- Function to create notifications for workflow changes
CREATE OR REPLACE FUNCTION public.create_workflow_notifications()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Notify reporter when report is approved or rejected
  IF NEW.status = 'approved' AND OLD.status != 'approved' THEN
    INSERT INTO public.notifications (user_id, ncp_report_id, title, message, type)
    VALUES (
      NEW.reporter_id,
      NEW.id,
      'NCP Report Approved',
      'Your NCP report ' || NEW.ncp_number || ' has been fully approved.',
      'approval_success'
    );
  ELSIF NEW.status = 'rejected' AND OLD.status != 'rejected' THEN
    INSERT INTO public.notifications (user_id, ncp_report_id, title, message, type)
    VALUES (
      NEW.reporter_id,
      NEW.id,
      'NCP Report Rejected',
      'Your NCP report ' || NEW.ncp_number || ' has been rejected. Please review the comments.',
      'approval_rejected'
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger for workflow notifications
DROP TRIGGER IF EXISTS workflow_notifications ON public.ncp_reports;
CREATE TRIGGER workflow_notifications
  AFTER UPDATE ON public.ncp_reports
  FOR EACH ROW
  EXECUTE FUNCTION public.create_workflow_notifications();
