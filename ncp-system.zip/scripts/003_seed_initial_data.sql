-- Insert default departments
INSERT INTO public.departments (name, description) VALUES
  ('Quality Assurance', 'Quality control and assurance department'),
  ('Production', 'Manufacturing and production department'),
  ('Engineering', 'Product and process engineering'),
  ('Materials', 'Materials management and procurement'),
  ('Maintenance', 'Equipment maintenance and repair')
ON CONFLICT (name) DO NOTHING;

-- Create default superadmin user (will be created when first user signs up with superadmin role)
-- This is handled by the trigger function
