export type UserRole = "superadmin" | "qa_inspector" | "qa_leader" | "team_leader" | "process_lead" | "qa_manager"

export type NCPStatus =
  | "draft"
  | "submitted"
  | "qa_leader_review"
  | "team_leader_review"
  | "process_lead_review"
  | "qa_manager_review"
  | "approved"
  | "rejected"
  | "closed"

export type NCPPriority = "low" | "medium" | "high" | "critical"

export type NCPCategory =
  | "product_defect"
  | "process_deviation"
  | "documentation_error"
  | "equipment_failure"
  | "material_issue"
  | "other"

export interface Profile {
  id: string
  email: string
  full_name: string
  role: UserRole
  department?: string
  phone?: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface Department {
  id: string
  name: string
  description?: string
  head_id?: string
  is_active: boolean
  created_at: string
}

export interface NCPReport {
  id: string
  ncp_number: string
  title: string
  description: string
  category: NCPCategory
  priority: NCPPriority
  status: NCPStatus

  // Reporter information
  reporter_id: string
  department_id?: string

  // Product/Process details
  product_name?: string
  batch_number?: string
  quantity_affected?: number
  date_discovered?: string
  location?: string

  // Root cause analysis
  root_cause?: string
  immediate_action?: string
  corrective_action?: string
  preventive_action?: string

  // Approval workflow
  qa_leader_id?: string
  qa_leader_approved_at?: string
  qa_leader_comments?: string

  team_leader_id?: string
  team_leader_approved_at?: string
  team_leader_comments?: string

  process_lead_id?: string
  process_lead_approved_at?: string
  process_lead_comments?: string

  qa_manager_id?: string
  qa_manager_approved_at?: string
  qa_manager_comments?: string

  // Timestamps
  submitted_at?: string
  closed_at?: string
  created_at: string
  updated_at: string
}

export interface NCPAttachment {
  id: string
  ncp_report_id: string
  file_name: string
  file_path: string
  file_size?: number
  mime_type?: string
  uploaded_by: string
  created_at: string
}

export interface AuditTrail {
  id: string
  ncp_report_id: string
  user_id: string
  action: string
  old_values?: any
  new_values?: any
  comments?: string
  created_at: string
}

export interface Notification {
  id: string
  user_id: string
  ncp_report_id?: string
  title: string
  message: string
  type: string
  is_read: boolean
  created_at: string
}
